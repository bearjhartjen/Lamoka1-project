#include "devbrain.hpp"

#include <algorithm>
#include <cstdint>

namespace {

enum class Mode : std::uint8_t {
    Charge,
    Inverter,
    Diagnostic,
    Rainbow,
    Off,
};

Mode mode = Mode::Charge;
std::uint32_t boot_ms = 0;
bool booting = true;

const char* mode_name() {
    switch (mode) {
        case Mode::Charge: return "Charge";
        case Mode::Inverter: return "Inverter";
        case Mode::Diagnostic: return "Diagnostic";
        case Mode::Rainbow: return "Rainbow";
        case Mode::Off: return "Off";
    }
    return "Unknown";
}

void next_mode() {
    mode = static_cast<Mode>((static_cast<unsigned>(mode) + 1u) % 5u);
    devbrain::set_status(mode_name());
    devbrain::log(mode_name());
}

devbrain::Rgb wheel(std::uint8_t position) {
    const std::uint8_t p = static_cast<std::uint8_t>(255u - position);
    if (p < 85u) {
        return {static_cast<std::uint8_t>(255u - p * 3u), 0, static_cast<std::uint8_t>(p * 3u)};
    }
    if (p < 170u) {
        const std::uint8_t q = static_cast<std::uint8_t>(p - 85u);
        return {0, static_cast<std::uint8_t>(q * 3u), static_cast<std::uint8_t>(255u - q * 3u)};
    }
    const std::uint8_t q = static_cast<std::uint8_t>(p - 170u);
    return {static_cast<std::uint8_t>(q * 3u), static_cast<std::uint8_t>(255u - q * 3u), 0};
}

void render_boot() {
    using namespace devbrain;
    if (boot_ms < 180) {
        leds::fill(32, 0, 0);
    } else if (boot_ms < 360) {
        leds::fill(0, 32, 0);
    } else if (boot_ms < 540) {
        leds::fill(0, 0, 32);
    } else if (boot_ms < 620) {
        leds::clear();
    } else if (boot_ms < 1220) {
        leds::clear();
        const int index = std::min<int>((boot_ms - 620) / 60, kLedCount - 1);
        leds::set(index, 30, 30, 30);
    } else {
        booting = false;
        set_status(mode_name());
        log("Startup self-test complete.");
    }
}

void render_mode() {
    using namespace devbrain;
    leds::clear();
    const std::uint64_t f = frame();

    switch (mode) {
        case Mode::Charge: {
            const int progress = static_cast<int>((f / 5u) % (kLedCount + 1));
            for (int i = 0; i < progress; ++i) {
                leds::set(i, 0, static_cast<std::uint8_t>(20 + i * 3), 2);
            }
            break;
        }
        case Mode::Inverter: {
            const std::uint8_t phase = static_cast<std::uint8_t>(f % 40u);
            const std::uint8_t triangle = phase < 20 ? phase : static_cast<std::uint8_t>(39 - phase);
            leds::fill(static_cast<std::uint8_t>(9 + triangle), 0, 0);
            break;
        }
        case Mode::Diagnostic: {
            const int index = static_cast<int>((f / 3u) % kLedCount);
            leds::set(index, 26, 8, 36);
            if (index > 0) leds::set(index - 1, 4, 1, 7);
            break;
        }
        case Mode::Rainbow:
            for (int i = 0; i < kLedCount; ++i) {
                leds::set(i, wheel(static_cast<std::uint8_t>((i * 256 / kLedCount + f * 2) & 0xff)));
            }
            break;
        case Mode::Off:
            break;
    }
}

}  // namespace

void setup() {
    mode = Mode::Charge;
    boot_ms = 0;
    booting = true;
    devbrain::leds::clear();
    devbrain::set_status("Startup self-test");
    devbrain::log("Firmware setup() entered.");
}

void update(std::uint32_t delta_ms) {
    if (devbrain::button::pressed() && !booting) {
        next_mode();
    }

    if (booting) {
        boot_ms += delta_ms;
        render_boot();
    } else {
        render_mode();
    }
}
