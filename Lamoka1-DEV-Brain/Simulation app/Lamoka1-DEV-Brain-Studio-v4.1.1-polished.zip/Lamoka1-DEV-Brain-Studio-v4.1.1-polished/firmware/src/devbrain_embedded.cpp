#include "devbrain.hpp"

#include <array>
#include <cstdint>
#include <cstdio>

namespace {
std::array<devbrain::Rgb, devbrain::kLedCount> g_leds{};
std::uint64_t g_millis = 0;
std::uint64_t g_frame = 0;
bool g_gpio0 = true;
bool g_pressed = false;
bool g_released = false;
const char* g_status = "Starting";
}

namespace devbrain {
namespace leds {
void set(int index, Rgb color) {
    if (index >= 0 && index < kLedCount) g_leds[static_cast<std::size_t>(index)] = color;
}
void set(int index, std::uint8_t r, std::uint8_t g, std::uint8_t b) { set(index, {r, g, b}); }
void fill(Rgb color) { g_leds.fill(color); }
void fill(std::uint8_t r, std::uint8_t g, std::uint8_t b) { fill({r, g, b}); }
void clear() { fill({0, 0, 0}); }
Rgb get(int index) { return index >= 0 && index < kLedCount ? g_leds[static_cast<std::size_t>(index)] : Rgb{}; }
}
namespace button {
bool down() { return !g_gpio0; }
bool pressed() { return g_pressed; }
bool released() { return g_released; }
}
std::uint64_t millis() { return g_millis; }
std::uint64_t frame() { return g_frame; }
bool power_good() { return true; }
void log(const char* text) { std::printf("[FW] %s\n", text ? text : ""); }
void set_status(const char* text) { g_status = text ? text : ""; std::printf("[STATUS] %s\n", g_status); }
}

extern "C" {
void db_embedded_set_button(bool stable_gpio0, bool pressed, bool released) {
    g_gpio0 = stable_gpio0;
    g_pressed = pressed;
    g_released = released;
}
void db_embedded_advance(std::uint32_t delta_ms) {
    g_millis += delta_ms;
    update(delta_ms);
    ++g_frame;
    g_pressed = false;
    g_released = false;
}
const devbrain::Rgb* db_embedded_leds() { return g_leds.data(); }
}
