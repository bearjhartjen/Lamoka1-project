#include "devbrain.hpp"

#include <cstdint>

#include "hardware/pio.h"
#include "pico/stdlib.h"
#include "ws2812.pio.h"

extern "C" {
void db_embedded_set_button(bool stable_gpio0, bool pressed, bool released);
void db_embedded_advance(std::uint32_t delta_ms);
const devbrain::Rgb* db_embedded_leds();
}

namespace {
constexpr std::uint32_t kTickMs = 10;
constexpr std::uint32_t kDebounceMs = 25;
PIO pio = pio0;
uint sm = 0;

std::uint32_t grb(const devbrain::Rgb& c) {
    return (static_cast<std::uint32_t>(c.g) << 24u)
         | (static_cast<std::uint32_t>(c.r) << 16u)
         | (static_cast<std::uint32_t>(c.b) << 8u);
}

void show_leds() {
    const auto* leds = db_embedded_leds();
    for (int i = 0; i < devbrain::kLedCount; ++i) {
        pio_sm_put_blocking(pio, sm, grb(leds[i]));
    }
    sleep_us(80);
}
}

int main() {
    stdio_init_all();
    gpio_init(devbrain::kButtonGpio);
    gpio_set_dir(devbrain::kButtonGpio, GPIO_IN);
    gpio_pull_up(devbrain::kButtonGpio);

    const uint offset = pio_add_program(pio, &ws2812_program);
    sm = pio_claim_unused_sm(pio, true);
    ws2812_program_init(pio, sm, offset, devbrain::kLedDataGpio, 800000.0f);

    sleep_ms(100);
    setup();

    bool raw = true;
    bool stable = true;
    std::uint32_t stable_for = 0;

    while (true) {
        const bool next_raw = gpio_get(devbrain::kButtonGpio);
        bool pressed = false;
        bool released = false;
        if (next_raw != raw) {
            raw = next_raw;
            stable_for = 0;
        } else if (stable_for < kDebounceMs) {
            stable_for += kTickMs;
        }
        if (stable_for >= kDebounceMs && stable != raw) {
            const bool old = stable;
            stable = raw;
            pressed = old && !stable;
            released = !old && stable;
        }
        db_embedded_set_button(stable, pressed, released);
        db_embedded_advance(kTickMs);
        show_leds();
        sleep_ms(kTickMs);
    }
}
