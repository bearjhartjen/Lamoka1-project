#!/usr/bin/env bash
# Lamoka1 DEV-Brain Studio — update helper.
# Re-runs install-fedora.sh which already does atomic swap + workspace preservation
# + rollback on failure. This script exists so users have a stable command name
# for updates and so a preserved-workspace hint is always seen.
set -euo pipefail

SOURCE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEST="$HOME/.local/share/lamoka1-devbrain-studio"

if [[ ! -d "$DEST" ]]; then
  echo "No previous install found at $DEST — running a fresh install." >&2
fi

CURRENT="unknown"
[[ -f "$DEST/VERSION" ]] && CURRENT="$(cat "$DEST/VERSION")"
NEW="$(cat "$SOURCE/VERSION" 2>/dev/null || echo unknown)"
printf 'Updating Lamoka1 DEV-Brain Studio: %s -> %s\n' "$CURRENT" "$NEW"
printf 'Workspace and user firmware WILL be preserved.\n\n'

exec "$SOURCE/install-fedora.sh" "$@"
