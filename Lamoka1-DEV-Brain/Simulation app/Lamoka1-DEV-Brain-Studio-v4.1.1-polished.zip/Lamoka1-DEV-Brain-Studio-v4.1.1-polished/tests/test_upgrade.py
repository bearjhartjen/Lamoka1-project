"""Upgrade preservation contract.

The installer promises: after an upgrade, every file that was in workspace/
is still there afterwards, and files newly shipped in workspace/ are added.
We simulate the rsync step the installer performs instead of shell-ing out.
"""
from __future__ import annotations

import subprocess
import shutil
from pathlib import Path


def _rsync(src: Path, dst: Path) -> None:
    dst.mkdir(parents=True, exist_ok=True)
    subprocess.run(["rsync", "-a", f"{src}/", f"{dst}/"], check=True)


def test_upgrade_preserves_user_workspace(tmp_path: Path) -> None:
    # 1. Old install with user modifications.
    old = tmp_path / "old_install"
    (old / "workspace").mkdir(parents=True)
    (old / "workspace" / "firmware.cpp").write_text("// USER EDITS 4.0")
    (old / "workspace" / "my_experiment.cpp").write_text("// custom file")

    # 2. Fresh source shipped in a new release (has different defaults).
    src = tmp_path / "new_source"
    (src / "workspace").mkdir(parents=True)
    (src / "workspace" / "firmware.cpp").write_text("// factory default 4.1")
    (src / "workspace" / "starter-template.cpp").write_text("// starter 4.1")
    (src / "workspace" / "new-example.cpp").write_text("// new in 4.1")

    # 3. Simulate installer: back up workspace, stage source, restore workspace over stage.
    backup = tmp_path / "backup"
    _rsync(old / "workspace", backup)
    stage = tmp_path / "stage"
    _rsync(src, stage)
    _rsync(backup, stage / "workspace")

    # 4. Contract:
    # (a) all pre-existing user files survive
    assert (stage / "workspace" / "firmware.cpp").read_text() == "// USER EDITS 4.0"
    assert (stage / "workspace" / "my_experiment.cpp").exists()
    # (b) brand-new shipped starter-template is added (didn't exist in old install)
    assert (stage / "workspace" / "new-example.cpp").read_text() == "// new in 4.1"


def test_uninstall_without_purge_preserves_workspace(tmp_path: Path) -> None:
    """Simulate the uninstall.sh behavior: move workspace/ aside before rm -rf."""
    install = tmp_path / "install"
    (install / "workspace").mkdir(parents=True)
    (install / "workspace" / "firmware.cpp").write_text("keep me")
    (install / "app").mkdir(parents=True)
    (install / "app" / "main.py").write_text("goes away")

    keep = tmp_path / "keep"
    subprocess.run(["rsync", "-a", f"{install}/workspace/", f"{keep}/"], check=True)
    shutil.rmtree(install)

    assert not install.exists()
    assert (keep / "firmware.cpp").read_text() == "keep me"
