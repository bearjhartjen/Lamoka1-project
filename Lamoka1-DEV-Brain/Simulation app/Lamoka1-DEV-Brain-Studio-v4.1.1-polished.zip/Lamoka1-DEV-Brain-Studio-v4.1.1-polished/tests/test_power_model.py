from app.power_model import PowerModel


def test_power_sequence() -> None:
    model = PowerModel()
    leds = [[0, 20, 0] for _ in range(10)]
    for _ in range(300):
        state = model.update(0.01, leds, insertion=1.0, source_v=5.0, cable_resistance_ohm=0.2, current_limit_a=1.5)
    assert state.power_good
    assert 4.7 < state.v5 <= 5.0
    assert 3.1 < state.v3v3 <= 3.31
    assert 1.0 < state.v1v1 <= 1.11


def test_partial_usb_has_no_power() -> None:
    model = PowerModel()
    state = model.update(0.1, [[0, 0, 0]] * 10, insertion=0.85, source_v=5.0, cable_resistance_ohm=0.2, current_limit_a=1.5)
    assert not state.usb_connected
    assert not state.power_good
