"""Coordinate & calibration tests.

These verify that the shipped assets/board-layout.json is self-consistent
(monotonic LED spacing, in-range values, matches physical 70x30mm aspect)
and that transforms between normalized PCB-space and pixel-space round-trip.
"""
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
LAYOUT = json.loads((ROOT / "assets" / "board-layout.json").read_text())


def _norm_to_px(nx: float, ny: float, w: float, h: float) -> tuple[float, float]:
    return nx * w, ny * h


def _px_to_norm(x: float, y: float, w: float, h: float) -> tuple[float, float]:
    return x / w, y / h


def test_pcb_dimensions_match_physical() -> None:
    w_mm, h_mm = LAYOUT["pcb_mm"]
    assert (w_mm, h_mm) == (70.0, 30.0)


def test_led_count_and_range() -> None:
    leds = LAYOUT["leds"]
    assert len(leds) == 10
    for nx, ny in leds:
        assert 0.0 < nx < 1.0
        assert 0.0 < ny < 1.0


def test_led_spacing_is_monotonic_and_even() -> None:
    xs = [nx for nx, _ in LAYOUT["leds"]]
    diffs = [b - a for a, b in zip(xs, xs[1:])]
    mean = sum(diffs) / len(diffs)
    assert all(d > 0 for d in diffs), "D1..D10 must be strictly left-to-right"
    max_dev = max(abs(d - mean) for d in diffs) / mean
    assert max_dev < 0.05, f"LED spacing drift {max_dev:.3%} exceeds 5%"


def test_leds_are_on_single_row() -> None:
    ys = [ny for _, ny in LAYOUT["leds"]]
    assert max(ys) - min(ys) < 0.005, "All 10 LEDs must share a Y row within 0.5%"


def test_button_and_usb_are_on_pcb() -> None:
    bx, by, bw, bh = LAYOUT["button"]
    ux, uy, uw, uh = LAYOUT["usb_port"]
    assert 0.0 <= bx <= 1.0 and 0.0 <= by <= 1.0
    assert bw > 0 and bh > 0
    # USB may sit flush at the PCB edge (x = 0.0) — a legal receptacle position.
    assert 0.0 <= ux < 0.5
    assert 0.0 < uy < 1.0 and uw > 0 and uh > 0


def test_norm_pixel_roundtrip() -> None:
    W, H = 979.0, 418.0  # actual PCB bbox in the bundled render
    for nx, ny in LAYOUT["leds"]:
        x, y = _norm_to_px(nx, ny, W, H)
        rnx, rny = _px_to_norm(x, y, W, H)
        assert abs(nx - rnx) < 1e-9 and abs(ny - rny) < 1e-9


def test_bundled_render_present_or_fallback() -> None:
    actual = ROOT / "assets" / "actual-devbrain.png"
    fallback = ROOT / "assets" / "fallback-board.png"
    assert actual.exists() or fallback.exists(), \
        "At least one board image (actual or fallback) must ship with the app"
