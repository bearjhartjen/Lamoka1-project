"""USB-C insertion state machine test.

Mirrors the thresholds in app/widgets/board_scene.py::UsbPlugItem._recalculate
and app/power_model.py — this test locks the contract so the two never drift.
"""
from __future__ import annotations

import pytest

from app.power_model import PowerModel


# Thresholds must match UsbPlugItem._recalculate.
STATE_TABLE = [
    (0.00, "DISCONNECTED"),
    (0.03, "DISCONNECTED"),
    (0.10, "ALIGNED"),
    (0.24, "ALIGNED"),
    (0.35, "SHELL ENGAGED"),
    (0.69, "SHELL ENGAGED"),
    (0.75, "CONTACTS ENGAGED"),
    (0.93, "CONTACTS ENGAGED"),
    (0.95, "CONNECTED"),
    (1.00, "CONNECTED"),
]


def classify(insertion: float) -> str:
    if insertion < 0.04:
        return "DISCONNECTED"
    if insertion < 0.25:
        return "ALIGNED"
    if insertion < 0.70:
        return "SHELL ENGAGED"
    if insertion < 0.94:
        return "CONTACTS ENGAGED"
    return "CONNECTED"


@pytest.mark.parametrize("insertion,expected", STATE_TABLE)
def test_insertion_state_bins(insertion: float, expected: str) -> None:
    assert classify(insertion) == expected


def test_power_model_gates_on_full_insertion() -> None:
    """Power must NOT come up until insertion >= 0.94 (contacts fully engaged)."""
    model = PowerModel()
    leds = [[0, 0, 0]] * 10
    # Ramp insertion slowly; power should stay at 0 until we cross threshold.
    connected_at = None
    for i in range(0, 101):
        ins = i / 100.0
        s = model.update(0.01, leds, insertion=ins, source_v=5.0,
                          cable_resistance_ohm=0.2, current_limit_a=1.5)
        if s.usb_connected and connected_at is None:
            connected_at = ins
    assert connected_at is not None
    assert connected_at >= 0.94, f"Power came up prematurely at insertion={connected_at}"


def test_shell_engaged_without_contacts() -> None:
    """Between 0.38 and 0.82, the shell is engaged but rails must stay off."""
    model = PowerModel()
    leds = [[0, 0, 0]] * 10
    for _ in range(20):
        s = model.update(0.01, leds, insertion=0.60, source_v=5.0,
                          cable_resistance_ohm=0.2, current_limit_a=1.5)
    assert s.shell_engaged
    assert not s.contacts_engaged
    assert not s.usb_connected
    assert s.v5 < 0.5


def test_brownout_on_source_collapse() -> None:
    """Rails must decay and power_good must clear if the source voltage drops out."""
    model = PowerModel()
    leds = [[0, 20, 0]] * 10
    for _ in range(300):
        model.update(0.01, leds, insertion=1.0, source_v=5.0,
                     cable_resistance_ohm=0.2, current_limit_a=1.5)
    assert model.state.power_good
    # Yank the cable.
    for _ in range(400):
        s = model.update(0.01, leds, insertion=0.0, source_v=5.0,
                         cable_resistance_ohm=0.2, current_limit_a=1.5)
    assert not s.power_good
    assert s.v5 < 0.5 and s.v3v3 < 0.5 and s.v1v1 < 0.5


def test_5v_fault_kills_downstream_rails() -> None:
    model = PowerModel()
    for _ in range(300):
        s = model.update(0.01, [[0, 0, 0]] * 10, insertion=1.0, source_v=5.0,
                         cable_resistance_ohm=0.2, current_limit_a=1.5, fault_5v=True)
    assert not s.power_good
    assert s.v5 < 0.5 and s.v3v3 < 0.5 and s.v1v1 < 0.5
    assert "5 V fault" in s.warning
