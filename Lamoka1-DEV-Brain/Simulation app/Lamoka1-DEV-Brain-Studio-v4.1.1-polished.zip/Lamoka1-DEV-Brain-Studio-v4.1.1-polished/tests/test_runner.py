from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    plugin = root / "workspace" / "build" / "libfirmware.so"
    process = subprocess.Popen(
        [sys.executable, str(root / "runtime" / "runner.py"), str(plugin)],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    assert process.stdin and process.stdout
    ready = json.loads(process.stdout.readline())
    assert ready["ok"] and ready["ready"]
    process.stdin.write(json.dumps({"cmd": "tick", "dt_ms": 20, "gpio0": True, "power_good": True}) + "\n")
    process.stdin.flush()
    state = json.loads(process.stdout.readline())
    assert state["ok"]
    assert len(state["leds"]) == 10
    process.stdin.write(json.dumps({"cmd": "shutdown"}) + "\n")
    process.stdin.flush()
    process.wait(timeout=3)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
