# Lamoka1 DEV-Brain Studio 4.1

A fully local Fedora desktop application for developing and testing the
experimental Lamoka1 DEV-Brain before the physical RP2354A board arrives.

This release **bundles the exact repository board render** and re-calibrates
every interactive overlay against it, so D1–D10, SW1, and the USB-C
receptacle line up with the real board out of the box, offline.

Install into:

```text
~/.local/share/lamoka1-devbrain-studio
```

After installation, the ZIP and any extracted Downloads folder can be deleted.
Upgrades preserve the entire `workspace/`. Uninstalls preserve user firmware
unless you pass `--purge`.

See `CHANGELOG.md` for what's new in 4.1, `docs/CALIBRATION.md` for the
coordinate system, and `docs/VERIFICATION.md` for an honest list of what was
and was not tested in the release environment.

## What is actually simulated

- The real firmware-facing hardware map:
  - GPIO0: active-low SW1 / BOOTSEL button
  - GPIO11: ten-device WS2812B chain
  - RP2354A target for the real UF2 build
- A correctly scaled USB-C plug that physically enters the rendered receptacle, with alignment, shell engagement, contact engagement, and full insertion states
- USB source voltage, cable and connector resistance, source current limiting, voltage drop, and rail rise/decay
- 5V, 3V3, and 1V1 fault injection
- U2 dissipation and approximate thermal behavior
- Button contact bounce followed by the same 25 ms debounce in the host and RP2354A runtime adapters
- Live LED frame, GRB values, current estimate, GPIO11 waveform, firmware console, and rail history

The installer automatically uses the exact repository render at:

```text
Lamoka1-project/Images/Lamoka1-DEV-Brain.png
```

when it exists on the computer. Studio 4 automatically removes the render’s transparent canvas and detects the ten blue WS2812 lenses, so color is composited directly onto D1-D10 instead of appearing in a detached row. SW1 remains the clickable switch in the board image. A fallback PCB illustration is included only for machines without the repo.

## Real C++ firmware workflow

The Firmware C++ tab is not decorative. It supports:

- Importing or dragging in a `.cpp` file
- Editing and saving C++ locally
- `Ctrl+B` / **Build & Run**
- Compiling the program with `g++` into an isolated local firmware plugin
- Hot-loading it into a separate runner process
- Showing compiler errors and runtime failures without destroying the main application
- Building the same source into an RP2354A UF2 after the Pico SDK is installed

A firmware program implements:

```cpp
#include "devbrain.hpp"

void setup() {
    devbrain::leds::clear();
}

void update(std::uint32_t delta_ms) {
    if (devbrain::button::pressed()) {
        devbrain::leds::fill(0, 30, 0);
    }
}
```

The same source file is compiled against two adapters:

```text
Your firmware.cpp
├── host_runtime.cpp        → local simulator plugin (.so)
└── devbrain_embedded.cpp   → RP2354A UF2 via Pico SDK
```

## Install or replace the previous app

```bash
chmod +x replace-old-version.sh
./replace-old-version.sh
```

The installer preserves the currently active `workspace/firmware.cpp` while replacing an older Studio version. The package includes the Qt runtime wheels, so installation and later use do not require an internet connection when the required Fedora compiler/Python tools are already installed.

## Install

```bash
chmod +x install-fedora.sh
./install-fedora.sh
```

The installer:
- checks Fedora dependencies (`gcc-c++`, `python3`, `cmake`, `ninja-build`,
  `rsync`, `desktop-file-utils`) and installs any that are missing via `sudo dnf`;
- stages the new install into `${DEST}.new`, promotes atomically with `mv`,
  and keeps `${DEST}.prev` for one cycle so you can manually roll back;
- rolls back automatically on any failure via `trap ... ERR`;
- preserves your entire `workspace/` (all `.cpp` files, not just `firmware.cpp`);
- prefers a local `Lamoka1-project/Images/Lamoka1-DEV-Brain.png` if present,
  otherwise uses the bundled render, otherwise falls back to the illustration.

Launch from KDE/GNOME or:

```bash
lamoka-devbrain-studio
```

## Upgrade

```bash
./update.sh
```

Delegates to `install-fedora.sh`; your workspace is preserved.

## Uninstall

```bash
./uninstall.sh              # keep workspace at ~/.local/share/lamoka1-devbrain-workspace
./uninstall.sh --purge      # delete user data too
```

## Build the real UF2 later

Install the ARM compiler and Pico SDK once, then use the button in the
Firmware C++ tab, or run:

```bash
~/.local/share/lamoka1-devbrain-studio/tools/setup_firmware_fedora.sh
~/.local/share/lamoka1-devbrain-studio/tools/build_real_uf2.sh \
  ~/.local/share/lamoka1-devbrain-studio/workspace/firmware.cpp
```

The UF2 lands in:

```text
~/.local/share/lamoka1-devbrain-studio/workspace/build-rp2354a/lamoka1_dev_brain.uf2
```

## Accuracy boundary

This is a firmware and board-behavior simulator, not transistor-level SPICE
and not an RP2354A instruction-set emulator. It does not guarantee crystal
startup, regulator loop stability, USB signal integrity, PCB noise behavior,
solder quality, or physical WS2812 timing margin. Those require the actual
board, an oscilloscope, and current-limited bring-up.
