# DEV-Brain portable C++ API

Every program includes `devbrain.hpp` and defines:

```cpp
void setup();
void update(std::uint32_t delta_ms);
```

## LEDs

```cpp
devbrain::leds::set(index, r, g, b);
devbrain::leds::set(index, devbrain::Rgb{r, g, b});
devbrain::leds::fill(r, g, b);
devbrain::leds::clear();
auto color = devbrain::leds::get(index);
```

## Button

```cpp
devbrain::button::down();
devbrain::button::pressed();
devbrain::button::released();
```

The button is physically active-low on GPIO0. The runtime adapters expose a debounced logical input.

## Time and state

```cpp
devbrain::millis();
devbrain::frame();
devbrain::power_good();
devbrain::log("message");
devbrain::set_status("Charge");
```

## Fixed board constants

```cpp
devbrain::kLedCount      // 10
devbrain::kButtonGpio    // 0
devbrain::kLedDataGpio   // 11
```
