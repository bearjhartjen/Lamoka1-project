# Calibration Guide

Studio 4.1 aligns its interactive overlays to the **exact PCB rendered in
`assets/actual-devbrain.png`**. Coordinates are stored as **fractions of the
tight PCB bounding box** (not the whole image canvas), so the same numbers
work at any window size or DPI.

## What is calibrated

| Element        | Field in `assets/board-layout.json` | Notes                                    |
|----------------|-------------------------------------|------------------------------------------|
| PCB size       | `pcb_mm`                            | Physical dimensions, always `[70, 30]`.  |
| D1–D10 centers | `leds`                              | 10 `[nx, ny]` pairs, left→right.         |
| LED package    | `led_size`, `led_package_scale`     | Blue lens size + housing multiplier.     |
| SW1 hitbox     | `button`                            | `[nx, ny, nw, nh]`, top-left + size.     |
| USB-C mouth    | `usb_port`                          | `[nx, ny, nw, nh]`, at PCB left edge.    |
| Insertion      | `usb_insertion_depth_mm`            | 8 mm, matches the physical receptacle.   |

Origin `(0, 0)` = PCB top-left. `(1, 1)` = PCB bottom-right. The PCB bounding
box is computed once at load time by `_content_crop()` in
`app/widgets/board_scene.py` (trims KiCad's transparent canvas).

## Two paths — auto and fallback

1. **`assets/actual-devbrain.png` present** (default in this release):
   `_detect_blue_led_packages()` scans the render and returns pixel-accurate
   D1–D10 rectangles. SW1 is inferred one LED-spacing to the left. `board-layout.json`
   is ignored for LED/SW1 positions but is still used for the USB-C receptacle.
2. **Only `fallback-board.png`**: every overlay is placed from `board-layout.json`.

## Values shipped with this release

Detected against `assets/actual-devbrain.png` (1920×733, PCB bbox
`(470, 157) – (1449, 575)`, aspect `2.342` vs. true `70/30 = 2.333`):

```
LED spacing:   0.0876 (normalized)   ≈ 6.13 mm on physical board
LED Y row:     0.1816                ≈ 5.45 mm from top edge
LED lens:      0.0449 × 0.1055       ≈ 3.14 × 3.17 mm
SW1 hitbox:    0.0577, 0.2225, 0.0848 × 0.1244
USB receptacle: 0.0000, 0.3660, 0.1140 × 0.2750   (flush with PCB left edge)
```

Aspect drift of `+0.4%` between the render and the true PCB dimensions is
below the 5% tolerance enforced by `tests/test_layout.py`.

## Developer calibration mode

Runtime detection is already accurate to a pixel. If a future render breaks
detection, re-derive coordinates with:

```bash
cd ~/.local/share/lamoka1-devbrain-studio
python3 -c "
from PIL import Image; import numpy as np
im = np.array(Image.open('assets/actual-devbrain.png').convert('RGBA'))
a = im[...,3]; rgb = im[...,:3].astype(int)
ys, xs = np.where((a>200) & (rgb[...,0]<90) & (rgb[...,1]<70) & (rgb[...,2]<70))
print('PCB bbox:', xs.min(), ys.min(), xs.max(), ys.max())
"
```

Paste the reported bbox into `assets/board-layout.json` as the reference for
any hand-drawn coordinates, then re-run `pytest tests/test_layout.py`.
