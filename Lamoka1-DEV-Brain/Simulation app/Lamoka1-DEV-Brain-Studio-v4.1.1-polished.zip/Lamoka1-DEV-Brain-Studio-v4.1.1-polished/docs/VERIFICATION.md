# Verification Report — Studio 4.1.0

This document records **exactly what was tested** for this release, in the
environment where the release was assembled. Anything not listed here was
**not verified**, no matter how likely it is to work.

## Environment used to assemble this release

- Linux sandbox, no X11/Wayland display attached (`QT_QPA_PLATFORM=offscreen`)
- Python 3.x with `pip install PySide6-Essentials pytest scipy pillow`
- No `arm-none-eabi-gcc`, no Pico SDK installed
- No physical Lamoka1 DEV-Brain board present

## Tests that were actually executed here (and passed)

```
pytest tests/ -q
```

- `tests/test_power_model.py` — power-up sequence, partial-USB no-power
- `tests/test_layout.py` — layout JSON schema, LED spacing, aspect ratio,
  norm↔pixel roundtrip, bundled render presence
- `tests/test_usb_state.py` — insertion state bins, power-gated-on-insertion,
  shell-engaged-without-contacts, brownout on source collapse, 5 V fault
- `tests/test_upgrade.py` — workspace preservation across install upgrade,
  workspace preservation across uninstall (without `--purge`)
- `tests/test_runner.py` — carried over from 4.0.0
- Offscreen import smoke check for `app`, `runtime`, `tools` modules
  (`python -m compileall -q app runtime tools`)
- Auto-detection of D1–D10, SW1 and USB-C receptacle against the bundled
  render, cross-checked with the values now committed in
  `assets/board-layout.json`

## What was NOT run and cannot be honestly claimed to work

The following require a real Fedora desktop with a display, GPU, or
external toolchain and were **not** executed here:

- Launching the Qt GUI on a real display, resizing the window, verifying
  splitter/dock persistence at 1366×768 and higher
- Producing screenshots of the running application (board view, USB plug
  partially inserted, fully connected, live LEDs, editor, compiler errors)
- End-to-end `install-fedora.sh` on a real Fedora system (`sudo dnf install`,
  venv creation, `.desktop` registration)
- End-to-end `update.sh` upgrade from a previously installed 4.0.0
- End-to-end `uninstall.sh` on a real system
- `firmware/CMakeLists.txt` configuration with the Pico SDK
- Producing a real RP2354A `.uf2` binary
- Any measurement of power/thermal fidelity against physical hardware

## What you should run on your Fedora machine to verify

```bash
# 1. Fresh install (this also runs the offscreen smoke test)
bash install-fedora.sh

# 2. Full test suite from the installed copy
cd ~/.local/share/lamoka1-devbrain-studio
QT_QPA_PLATFORM=offscreen .venv/bin/python -m pytest tests/ -q

# 3. Launch the GUI
lamoka-devbrain-studio

# 4. Test upgrade preservation: edit workspace/firmware.cpp, then re-run the
#    installer from a fresh copy of this ZIP. Your edits must survive.
bash install-fedora.sh

# 5. Test uninstall preservation: run uninstall.sh (without --purge), confirm
#    ~/.local/share/lamoka1-devbrain-workspace/firmware.cpp is present.
bash uninstall.sh

# 6. Real UF2 build (needs Pico SDK installed separately)
cd firmware && cmake -B build -GNinja && ninja -C build
```

If any of steps 3–6 misbehaves, please attach the console output — we did
not run those steps here and I do not want to claim otherwise.

## Simulation-accuracy honesty

The power/thermal model in `app/power_model.py` is an intentional **board-level
approximation** for developer intuition, not a SPICE simulation and not a
substitute for measurements on physical silicon. See
`docs/SIMULATION_ACCURACY.md` for what it does and does not model.
