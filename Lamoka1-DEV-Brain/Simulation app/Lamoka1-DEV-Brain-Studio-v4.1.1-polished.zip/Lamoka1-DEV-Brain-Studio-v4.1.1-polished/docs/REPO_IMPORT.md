The standalone package is intentionally outside the Lamoka1 repository. After it has been tested, copy the clean source folder into a dedicated directory such as `Lamoka1-DEV-Brain/Simulator/` and remove local build directories, the `.venv`, and generated UF2 files before committing.

Suggested files to keep:

- app/
- assets/
- docs/
- firmware/
- runtime/
- sdk/
- tools/
- workspace/starter-template.cpp
- README.md
- install-fedora.sh
- uninstall.sh

Do not commit `.venv/`, `workspace/build/`, or `workspace/build-rp2354a/`.
