#!/usr/bin/env bash
# Lamoka1 DEV-Brain Studio — uninstaller.
# By default this PRESERVES the user's workspace/ (C++ firmware, settings).
# Pass --purge to also delete user data.
set -euo pipefail

PURGE=0
[[ "${1:-}" == "--purge" ]] && PURGE=1

DEST="$HOME/.local/share/lamoka1-devbrain-studio"
BIN_DIR="$HOME/.local/bin"
APP_DIR="$HOME/.local/share/applications"
DATA_KEEP="$HOME/.local/share/lamoka1-devbrain-workspace"

pkill -f 'lamoka1-devbrain-studio' 2>/dev/null || true
pkill -f 'app.main' 2>/dev/null || true

if (( PURGE == 0 )) && [[ -d "$DEST/workspace" ]]; then
  mkdir -p "$DATA_KEEP"
  # Move (not copy) so the workspace survives the rm -rf below.
  rsync -a "$DEST/workspace/" "$DATA_KEEP/"
  printf 'Preserved workspace at: %s\n' "$DATA_KEEP"
fi

rm -f "$BIN_DIR/lamoka-devbrain-studio" "$BIN_DIR/lamoka-devbrain-sim"
rm -f "$APP_DIR/lamoka-devbrain-studio.desktop" "$APP_DIR/lamoka-devbrain-sim.desktop"
rm -rf "$DEST" "${DEST}.prev" "${DEST}.new"
rm -rf "$HOME/.local/share/lamoka1-devbrain-simulator"
update-desktop-database "$APP_DIR" >/dev/null 2>&1 || true

if (( PURGE == 1 )); then
  rm -rf "$DATA_KEEP"
  printf 'Purged all Lamoka1 DEV-Brain Studio data.\n'
else
  printf 'Removed application. User firmware preserved at:\n  %s\n' "$DATA_KEEP"
  printf 'Reinstalling will pick these files back up automatically.\n'
  printf 'To delete user data too: %s --purge\n' "$0"
fi
