from __future__ import annotations

import os
import random
import shutil
import sys
import time
from pathlib import Path

from PySide6.QtCore import QElapsedTimer, QProcess, QSettings, Qt, QTimer, Signal
from PySide6.QtGui import QAction, QColor, QFont, QIcon, QTextCursor
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QComboBox,
    QDoubleSpinBox,
    QFileDialog,
    QFrame,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QMainWindow,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QScrollArea,
    QSlider,
    QSplitter,
    QStatusBar,
    QTabWidget,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from .firmware_process import FirmwareProcess
from .power_model import PowerModel, PowerState
from .widgets.board_scene import BoardGraphicsView
from .widgets.code_editor import CodeEditor
from .widgets.graphs import GpioTrace, PowerGraph


class MetricRow(QWidget):
    def __init__(self, name: str, unit: str = "", parent=None) -> None:
        super().__init__(parent)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 2, 0, 2)
        self.dot = QLabel("●")
        self.dot.setStyleSheet("color:#8b949e")
        self.name = QLabel(name)
        self.value = QLabel("—")
        self.value.setObjectName("MetricValue")
        self.unit = unit
        layout.addWidget(self.dot)
        layout.addWidget(self.name, 1)
        layout.addWidget(self.value)

    def set_value(self, value: str, level: str = "neutral") -> None:
        self.value.setText(value + (f" {self.unit}" if self.unit else ""))
        color = {
            "good": "#55d66b",
            "warn": "#e3b341",
            "bad": "#ff6b70",
            "neutral": "#9fb0c3",
        }.get(level, "#9fb0c3")
        self.dot.setStyleSheet(f"color:{color}")
        self.value.setStyleSheet(f"color:{color}")


class MainWindow(QMainWindow):
    def __init__(self, root: Path) -> None:
        super().__init__()
        self.root = root
        self.settings = QSettings("FlamingoAndCactus", "Lamoka1DevBrainStudio")
        self.version = (root / "VERSION").read_text(encoding="utf-8").strip() if (root / "VERSION").exists() else "dev"
        self.setWindowTitle(f"Lamoka1 DEV-Brain Studio {self.version}")
        self.setMinimumSize(1280, 760)
        self.resize(1720, 980)
        icon = root / "assets" / "devbrain-studio.svg"
        if icon.exists():
            self.setWindowIcon(QIcon(str(icon)))

        self.power = PowerModel()
        self.firmware = FirmwareProcess(root, self)
        self.firmware.state_updated.connect(self._firmware_state_updated)
        self.firmware.log_lines.connect(self._append_firmware_logs)
        self.firmware.error.connect(self._firmware_error)
        self.firmware.ready_changed.connect(self._runner_ready_changed)

        self.firmware_state = {
            "leds": [[0, 0, 0] for _ in range(10)],
            "uptime_ms": 0,
            "frame": 0,
            "gpio0": 1,
            "power_good": False,
            "status": "Firmware not running",
        }
        self.current_source = root / "workspace" / "firmware.cpp"
        self.plugin_path = root / "workspace" / "build" / "libfirmware.so"
        self.paused = False
        self.speed = 1.0
        self.physical_button_down = False
        self.raw_gpio0_level = True
        self._bounce_target = True
        self._bounce_remaining_ms = 0
        self._bounce_phase_ms = 0
        self._last_usb_state = "DISCONNECTED"
        self._build_process: QProcess | None = None
        self._last_tick = time.monotonic()

        self._create_actions()
        self._build_ui()
        self._load_source(self.current_source, focus=False)

        self.sim_timer = QTimer(self)
        self.sim_timer.setTimerType(Qt.PreciseTimer)
        self.sim_timer.timeout.connect(self._simulation_tick)
        self.sim_timer.start(16)

        QTimer.singleShot(80, self.board_view.fit_board)
        QTimer.singleShot(250, self.board_view.connect_usb)
        QTimer.singleShot(350, self._ensure_firmware_running)

    # ---------- UI construction ----------

    def _create_actions(self) -> None:
        self.open_action = QAction("Import C++ firmware…", self)
        self.open_action.setShortcut("Ctrl+O")
        self.open_action.triggered.connect(self.import_cpp)
        self.save_action = QAction("Save", self)
        self.save_action.setShortcut("Ctrl+S")
        self.save_action.triggered.connect(self.save_source)
        self.save_as_action = QAction("Save As…", self)
        self.save_as_action.setShortcut("Ctrl+Shift+S")
        self.save_as_action.triggered.connect(self.save_source_as)
        self.build_action = QAction("Build && Run", self)
        self.build_action.setShortcut("Ctrl+B")
        self.build_action.triggered.connect(self.build_and_run)
        self.fit_action = QAction("Fit Board", self)
        self.fit_action.setShortcut("F")
        self.fit_action.triggered.connect(lambda: self.board_view.fit_board())

    def _build_ui(self) -> None:
        central = QWidget()
        outer = QVBoxLayout(central)
        outer.setContentsMargins(16, 12, 16, 10)
        outer.setSpacing(10)

        header_card = QFrame()
        header_card.setObjectName("HeaderCard")
        header = QHBoxLayout(header_card)
        header.setContentsMargins(16, 12, 16, 12)
        title = QLabel("Lamoka1 DEV-Brain")
        title.setObjectName("Title")
        subtitle = QLabel(f"local hardware + C++ firmware studio  ·  v{self.version}")
        subtitle.setObjectName("Subtitle")
        self.run_badge = QLabel("STARTING")
        self.run_badge.setAlignment(Qt.AlignCenter)
        self.run_badge.setMinimumWidth(100)
        self.run_badge.setObjectName("RunBadge")
        self._set_run_badge("STARTING", "starting")
        header.addWidget(title)
        header.addWidget(subtitle)
        header.addStretch(1)
        header.addWidget(self.run_badge)
        outer.addWidget(header_card)

        main_split = QSplitter(Qt.Horizontal)
        main_split.setChildrenCollapsible(False)
        main_split.addWidget(self._build_center_tabs())
        main_split.addWidget(self._build_sidebar())
        main_split.setSizes([1340, 340])
        main_split.setStretchFactor(0, 1)
        main_split.setStretchFactor(1, 0)
        outer.addWidget(main_split, 1)
        self.main_splitter = main_split

        self.setCentralWidget(central)
        self._build_menus()
        self._build_status_bar()


    def _set_run_badge(self, text: str, state: str) -> None:
        self.run_badge.setText(text)
        self.run_badge.setProperty("state", state)
        self.run_badge.style().unpolish(self.run_badge)
        self.run_badge.style().polish(self.run_badge)

    def _build_menus(self) -> None:
        file_menu = self.menuBar().addMenu("File")
        file_menu.addAction(self.open_action)
        file_menu.addAction(self.save_action)
        file_menu.addAction(self.save_as_action)
        file_menu.addSeparator()
        file_menu.addAction("Quit", self.close, "Ctrl+Q")
        firmware_menu = self.menuBar().addMenu("Firmware")
        firmware_menu.addAction(self.build_action)
        firmware_menu.addAction("Reset firmware", self.reset_firmware)
        firmware_menu.addAction("Build RP2354A UF2…", self.build_real_uf2)
        view_menu = self.menuBar().addMenu("View")
        view_menu.addAction(self.fit_action)
        help_menu = self.menuBar().addMenu("Help")
        help_menu.addAction("DEV-Brain C++ API", self.show_api_reference)
        help_menu.addAction("Simulation accuracy", self.show_accuracy)
        help_menu.addAction("About", self.show_about)

    def _build_status_bar(self) -> None:
        status = QStatusBar()
        self.setStatusBar(status)
        self.status_source = QLabel()
        self.status_board = QLabel("Board: DEV-Brain Rev A")
        self.status_mcu = QLabel("MCU target: RP2354A")
        self.status_pins = QLabel("GPIO0 button · GPIO11 WS2812 ×10")
        status.addWidget(self.status_source, 1)
        status.addPermanentWidget(self.status_board)
        status.addPermanentWidget(self.status_mcu)
        status.addPermanentWidget(self.status_pins)

    def _build_center_tabs(self) -> QWidget:
        self.center_tabs = QTabWidget()
        self.center_tabs.addTab(self._build_board_tab(), "Board")
        self.center_tabs.addTab(self._build_firmware_tab(), "Firmware C++")
        return self.center_tabs

    def _build_board_tab(self) -> QWidget:
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(5)

        toolbar = QHBoxLayout()
        board_view_label = QLabel("LIVE BOARD")
        board_view_label.setObjectName("SectionLabel")
        fit = QPushButton("Fit board  [F]")
        fit.setToolTip("Fit the complete board in the viewport (F)")
        fit.clicked.connect(self.board_view_fit_delayed)
        drag_hint = QLabel("Drag USB-C into the receptacle  ·  click SW1  ·  Ctrl+wheel to zoom  ·  double-click to fit")
        drag_hint.setObjectName("Muted")
        toolbar.addWidget(board_view_label)
        toolbar.addStretch(1)
        toolbar.addWidget(drag_hint)
        toolbar.addWidget(fit)
        layout.addLayout(toolbar)

        vertical = QSplitter(Qt.Vertical)
        self.board_view = BoardGraphicsView(self.root)
        self.board_view.button_changed.connect(self._board_button_changed)
        self.board_view.usb_insertion_changed.connect(self._usb_insertion_changed)
        self.board_view.usb_state_changed.connect(self._usb_state_changed)
        vertical.addWidget(self.board_view)

        self.lower_tabs = QTabWidget()
        self.console = QPlainTextEdit()
        self.console.setObjectName("Console")
        self.console.setReadOnly(True)
        self.console.setMaximumBlockCount(4000)
        self.lower_tabs.addTab(self.console, "Firmware console")
        self.lower_tabs.addTab(self._build_led_inspector(), "LED frame inspector")
        self.gpio_trace = GpioTrace()
        self.lower_tabs.addTab(self.gpio_trace, "GPIO11 data trace")
        self.power_graph = PowerGraph()
        self.lower_tabs.addTab(self.power_graph, "Power diagnostics")
        vertical.addWidget(self.lower_tabs)
        vertical.setSizes([690, 185])
        layout.addWidget(vertical, 1)
        return widget

    def _build_led_inspector(self) -> QWidget:
        container = QWidget()
        layout = QVBoxLayout(container)
        self.led_table = QTableWidget(10, 6)
        self.led_table.setHorizontalHeaderLabels(["Pixel", "R", "G", "B", "GRB word", "Estimated current"])
        self.led_table.verticalHeader().setVisible(False)
        self.led_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.led_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.led_table.setSelectionMode(QTableWidget.NoSelection)
        for row in range(10):
            self.led_table.setItem(row, 0, QTableWidgetItem(f"D{row + 1}"))
            for col in range(1, 6):
                self.led_table.setItem(row, col, QTableWidgetItem("0"))
        layout.addWidget(self.led_table)
        return container

    def _build_firmware_tab(self) -> QWidget:
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(0, 0, 0, 0)
        top = QHBoxLayout()
        self.import_button = QPushButton("Import C++  [Ctrl+O]")
        self.import_button.clicked.connect(self.import_cpp)
        self.save_button = QPushButton("Save  [Ctrl+S]")
        self.save_button.clicked.connect(self.save_source)
        self.save_as_button = QPushButton("Save As")
        self.save_as_button.clicked.connect(self.save_source_as)
        self.template_button = QPushButton("Restore starter firmware")
        self.template_button.clicked.connect(self.restore_template)
        self.build_button = QPushButton("Build & Run  [Ctrl+B]")
        self.build_button.setObjectName("PrimaryButton")
        self.build_button.clicked.connect(self.build_and_run)
        self.uf2_button = QPushButton("Build real RP2354A UF2")
        self.uf2_button.clicked.connect(self.build_real_uf2)
        top.addWidget(self.import_button)
        top.addWidget(self.save_button)
        top.addWidget(self.save_as_button)
        top.addWidget(self.template_button)
        top.addStretch(1)
        top.addWidget(self.uf2_button)
        top.addWidget(self.build_button)
        layout.addLayout(top)

        splitter = QSplitter(Qt.Vertical)
        self.editor = CodeEditor()
        self.editor.file_dropped.connect(self._load_source)
        self.editor.textChanged.connect(self._source_modified)
        splitter.addWidget(self.editor)
        self.build_output = QPlainTextEdit()
        self.build_output.setObjectName("Console")
        self.build_output.setReadOnly(True)
        self.build_output.setPlaceholderText("Compiler output appears here. Ctrl+B builds and hot-loads this C++ firmware into the board simulator.")
        splitter.addWidget(self.build_output)
        splitter.setSizes([620, 190])
        layout.addWidget(splitter, 1)

        hint = QLabel(
            "This editor compiles the same setup()/update() source against the local simulator backend. "
            "The real UF2 build compiles that same file against the Pico SDK RP2354A backend."
        )
        hint.setWordWrap(True)
        hint.setObjectName("Hint")
        layout.addWidget(hint)
        return widget

    def _build_sidebar(self) -> QWidget:
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setMinimumWidth(340)
        scroll.setMaximumWidth(430)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        content = QWidget()
        layout = QVBoxLayout(content)
        layout.setContentsMargins(10, 6, 10, 12)
        layout.setSpacing(10)

        layout.addWidget(self._build_sim_controls())
        layout.addWidget(self._build_usb_controls())
        layout.addWidget(self._build_power_diagnostics())
        layout.addWidget(self._build_fault_controls())
        layout.addWidget(self._build_input_controls())
        layout.addWidget(self._build_firmware_summary())
        layout.addStretch(1)
        scroll.setWidget(content)
        self.sidebar_scroll = scroll
        return scroll

    def _build_sim_controls(self) -> QGroupBox:
        group = QGroupBox("Simulation controls")
        layout = QGridLayout(group)
        reset = QPushButton("Reset firmware")
        reset.clicked.connect(self.reset_firmware)
        self.pause_button = QPushButton("Pause")
        self.pause_button.clicked.connect(self.toggle_pause)
        step = QPushButton("Step 20 ms")
        step.clicked.connect(lambda: self._run_simulation_step(20))
        fit = QPushButton("Fit board")
        fit.clicked.connect(self.board_view_fit_delayed)
        layout.addWidget(reset, 0, 0)
        layout.addWidget(self.pause_button, 0, 1)
        layout.addWidget(step, 1, 0)
        layout.addWidget(fit, 1, 1)
        layout.addWidget(QLabel("Simulation speed"), 2, 0)
        self.speed_combo = QComboBox()
        self.speed_combo.addItems(["0.25×", "0.5×", "1×", "2×", "4×"])
        self.speed_combo.setCurrentText("1×")
        self.speed_combo.currentTextChanged.connect(self._speed_changed)
        layout.addWidget(self.speed_combo, 2, 1)
        return group

    def _build_usb_controls(self) -> QGroupBox:
        group = QGroupBox("USB-C physical connection")
        layout = QVBoxLayout(group)
        text = QLabel("Drag the plug itself into the receptacle. Power appears only after the contacts are fully seated.")
        text.setWordWrap(True)
        text.setObjectName("Muted")
        layout.addWidget(text)
        self.usb_state_label = QLabel("DISCONNECTED")
        self.usb_state_label.setObjectName("Bad")
        layout.addWidget(self.usb_state_label)
        self.insertion_label = QLabel("Insertion depth: 0%")
        layout.addWidget(self.insertion_label)
        row = QHBoxLayout()
        connect = QPushButton("Insert fully")
        connect.clicked.connect(self.board_view.connect_usb)
        disconnect = QPushButton("Unplug")
        disconnect.clicked.connect(self.board_view.disconnect_usb)
        row.addWidget(connect)
        row.addWidget(disconnect)
        layout.addLayout(row)

        self.source_voltage = self._double_spin(5.00, 4.0, 5.5, 0.01, " V")
        self.cable_resistance = self._double_spin(0.20, 0.01, 2.0, 0.01, " Ω")
        self.current_limit = self._double_spin(1.50, 0.05, 5.0, 0.05, " A")
        grid = QGridLayout()
        grid.addWidget(QLabel("USB source"), 0, 0)
        grid.addWidget(self.source_voltage, 0, 1)
        grid.addWidget(QLabel("Cable resistance"), 1, 0)
        grid.addWidget(self.cable_resistance, 1, 1)
        grid.addWidget(QLabel("Current limit"), 2, 0)
        grid.addWidget(self.current_limit, 2, 1)
        layout.addLayout(grid)
        return group

    def _build_power_diagnostics(self) -> QGroupBox:
        group = QGroupBox("Power diagnostics")
        layout = QVBoxLayout(group)
        self.power_warning = QLabel("USB-C disconnected")
        self.power_warning.setWordWrap(True)
        self.power_warning.setObjectName("Warn")
        layout.addWidget(self.power_warning)
        self.metrics = {
            "v5": MetricRow("5V rail", "V"),
            "v3v3": MetricRow("3V3 rail", "V"),
            "v1v1": MetricRow("1V1 rail", "V"),
            "usb_current": MetricRow("USB current", "mA"),
            "cable_drop": MetricRow("Cable drop", "mV"),
            "contact_drop": MetricRow("Connector drop", "mV"),
            "led_current": MetricRow("LED current", "mA"),
            "u2_power": MetricRow("U2 dissipation", "mW"),
            "u2_temp": MetricRow("U2 estimated temp", "°C"),
        }
        for row in self.metrics.values():
            layout.addWidget(row)
        graph_button = QPushButton("Open rail-history graph")
        graph_button.clicked.connect(lambda: self.lower_tabs.setCurrentWidget(self.power_graph))
        layout.addWidget(graph_button)
        return group

    def _build_fault_controls(self) -> QGroupBox:
        group = QGroupBox("Fault injection")
        layout = QVBoxLayout(group)
        self.fault_5v = QCheckBox("Open/short the 5V rail")
        self.fault_3v3 = QCheckBox("Fail the 3V3 regulator output")
        self.fault_1v1 = QCheckBox("Fail the RP2354A 1V1 core rail")
        layout.addWidget(self.fault_5v)
        layout.addWidget(self.fault_3v3)
        layout.addWidget(self.fault_1v1)
        clear = QPushButton("Clear all injected faults")
        clear.clicked.connect(self.clear_faults)
        layout.addWidget(clear)
        return group

    def _build_input_controls(self) -> QGroupBox:
        group = QGroupBox("Physical input")
        layout = QVBoxLayout(group)
        self.bounce_check = QCheckBox("Simulate real switch contact bounce")
        self.bounce_check.setChecked(True)
        layout.addWidget(self.bounce_check)
        button = QPushButton("Press and hold DEV-Brain SW1")
        button.pressed.connect(lambda: self._board_button_changed(True))
        button.released.connect(lambda: self._board_button_changed(False))
        layout.addWidget(button)
        gpio = QLabel("GPIO0 is active-low. Clicking SW1 directly on the board does the same thing.")
        gpio.setWordWrap(True)
        gpio.setObjectName("Muted")
        layout.addWidget(gpio)
        return group

    def _build_firmware_summary(self) -> QGroupBox:
        group = QGroupBox("Active firmware")
        layout = QVBoxLayout(group)
        self.firmware_file_label = QLabel()
        self.firmware_file_label.setWordWrap(True)
        self.firmware_status_label = QLabel("Not loaded")
        self.firmware_status_label.setWordWrap(True)
        open_editor = QPushButton("Open C++ editor")
        open_editor.clicked.connect(lambda: self.center_tabs.setCurrentIndex(1))
        build = QPushButton("Build & hot-load")
        build.setObjectName("PrimaryButton")
        build.clicked.connect(self.build_and_run)
        layout.addWidget(self.firmware_file_label)
        layout.addWidget(self.firmware_status_label)
        layout.addWidget(open_editor)
        layout.addWidget(build)
        return group

    @staticmethod
    def _double_spin(value: float, low: float, high: float, step: float, suffix: str) -> QDoubleSpinBox:
        box = QDoubleSpinBox()
        box.setRange(low, high)
        box.setSingleStep(step)
        box.setDecimals(2)
        box.setValue(value)
        box.setSuffix(suffix)
        return box

    # ---------- Firmware editor/build ----------

    def _load_source(self, path: Path, focus: bool = True) -> None:
        try:
            text = path.read_text(encoding="utf-8")
        except Exception as exc:  # noqa: BLE001
            QMessageBox.critical(self, "Cannot open firmware", str(exc))
            return
        self.current_source = path.resolve()
        self.editor.blockSignals(True)
        self.editor.setPlainText(text)
        self.editor.document().setModified(False)
        self.editor.blockSignals(False)
        self._update_source_labels()
        if focus:
            self.center_tabs.setCurrentIndex(1)

    def import_cpp(self) -> None:
        filename, _ = QFileDialog.getOpenFileName(self, "Import DEV-Brain C++ firmware", str(Path.home()), "C++ source (*.cpp *.cc *.cxx);;All files (*)")
        if filename:
            self._load_source(Path(filename))

    def save_source(self) -> bool:
        if not self.current_source:
            return self.save_source_as()
        try:
            self.current_source.write_text(self.editor.toPlainText(), encoding="utf-8")
            self.editor.document().setModified(False)
            self._update_source_labels()
            return True
        except Exception as exc:  # noqa: BLE001
            QMessageBox.critical(self, "Cannot save firmware", str(exc))
            return False

    def save_source_as(self) -> bool:
        filename, _ = QFileDialog.getSaveFileName(self, "Save DEV-Brain C++ firmware", str(self.current_source), "C++ source (*.cpp)")
        if not filename:
            return False
        self.current_source = Path(filename)
        return self.save_source()

    def restore_template(self) -> None:
        template = self.root / "workspace" / "starter-template.cpp"
        if QMessageBox.question(self, "Restore starter firmware", "Replace the editor contents with the tested starter firmware?") == QMessageBox.Yes:
            self.editor.setPlainText(template.read_text(encoding="utf-8"))
            self.editor.document().setModified(True)

    def build_and_run(self) -> None:
        if self._build_process and self._build_process.state() != QProcess.NotRunning:
            QMessageBox.information(self, "Build running", "A firmware build is already running.")
            return
        if not self.save_source():
            return
        self.build_output.clear()
        self.build_output.appendPlainText("Compiling local C++ firmware plugin…\n")
        self.build_button.setEnabled(False)
        process = QProcess(self)
        process.setWorkingDirectory(str(self.root))
        process.setProcessChannelMode(QProcess.MergedChannels)
        process.readyReadStandardOutput.connect(lambda: self._append_build_bytes(process.readAllStandardOutput()))
        process.finished.connect(lambda code, status: self._build_finished(code, status))
        process.start(sys.executable, [
            str(self.root / "tools" / "build_user_firmware.py"),
            str(self.current_source),
            str(self.plugin_path),
            "--root",
            str(self.root),
        ])
        self._build_process = process
        self.center_tabs.setCurrentIndex(1)

    def _append_build_bytes(self, data) -> None:
        text = bytes(data).decode("utf-8", errors="replace")
        self.build_output.moveCursor(QTextCursor.End)
        self.build_output.insertPlainText(text)
        self.build_output.moveCursor(QTextCursor.End)

    def _build_finished(self, code: int, _status: QProcess.ExitStatus) -> None:
        self.build_button.setEnabled(True)
        if code == 0 and self.plugin_path.exists():
            self.build_output.appendPlainText("\nBUILD SUCCEEDED. Hot-loading firmware into a fresh isolated runner process…")
            self.firmware.start(self.plugin_path)
            self._append_event(f"Loaded C++ firmware: {self.current_source}")
            self.center_tabs.setCurrentIndex(0)
        else:
            self.build_output.appendPlainText(f"\nBUILD FAILED with exit code {code}.")
            self._set_run_badge("BUILD ERROR", "error")

    def build_real_uf2(self) -> None:
        if not self.save_source():
            return
        self.center_tabs.setCurrentIndex(1)
        self.build_output.appendPlainText("\n=== RP2354A UF2 BUILD ===\n")
        process = QProcess(self)
        process.setWorkingDirectory(str(self.root))
        process.setProcessChannelMode(QProcess.MergedChannels)
        process.readyReadStandardOutput.connect(lambda: self._append_build_bytes(process.readAllStandardOutput()))
        process.finished.connect(lambda code, _: self.build_output.appendPlainText(f"\nUF2 build exited with code {code}."))
        process.start("bash", [str(self.root / "tools" / "build_real_uf2.sh"), str(self.current_source)])
        self._build_process = process

    def _ensure_firmware_running(self) -> None:
        if self.plugin_path.exists():
            self.firmware.start(self.plugin_path)
        else:
            self.build_and_run()

    # ---------- Simulation ----------

    def _simulation_tick(self) -> None:
        now = time.monotonic()
        elapsed = min(0.1, max(0.001, now - self._last_tick))
        self._last_tick = now
        if self.paused:
            return
        self._run_simulation_step(max(1, int(elapsed * 1000 * self.speed)))

    def _run_simulation_step(self, dt_ms: int) -> None:
        leds = self.firmware_state.get("leds") or [[0, 0, 0] for _ in range(10)]
        power_state = self.power.update(
            dt_ms / 1000.0,
            leds,
            insertion=self.board_view.usb_insertion,
            source_v=self.source_voltage.value(),
            cable_resistance_ohm=self.cable_resistance.value(),
            current_limit_a=self.current_limit.value(),
            fault_5v=self.fault_5v.isChecked(),
            fault_3v3=self.fault_3v3.isChecked(),
            fault_1v1=self.fault_1v1.isChecked(),
        )
        self._update_bounce(dt_ms)
        self.firmware.tick(dt_ms, self.raw_gpio0_level, power_state.power_good)
        self._update_power_ui(power_state)
        self.power_graph.set_history(self.power.history)

    def _update_bounce(self, dt_ms: int) -> None:
        if not self.bounce_check.isChecked() or self._bounce_remaining_ms <= 0:
            self.raw_gpio0_level = self._bounce_target
            return
        self._bounce_remaining_ms -= dt_ms
        self._bounce_phase_ms += dt_ms
        if self._bounce_remaining_ms <= 0:
            self.raw_gpio0_level = self._bounce_target
        elif self._bounce_phase_ms >= 2:
            self._bounce_phase_ms = 0
            self.raw_gpio0_level = not self.raw_gpio0_level

    def _board_button_changed(self, pressed: bool) -> None:
        self.physical_button_down = pressed
        target_level = not pressed
        self._bounce_target = target_level
        self._bounce_remaining_ms = 16 if self.bounce_check.isChecked() else 0
        self._bounce_phase_ms = 0
        if not self.bounce_check.isChecked():
            self.raw_gpio0_level = target_level

    def _firmware_state_updated(self, state: dict) -> None:
        self.firmware_state = state
        leds = state.get("leds") or [[0, 0, 0] for _ in range(10)]
        self.board_view.set_leds(leds)
        self.gpio_trace.set_leds(leds)
        self._update_led_table(leds)
        self.firmware_status_label.setText(f"{state.get('status', '')}\nFrame {state.get('frame', 0):,} · uptime {state.get('uptime_ms', 0) / 1000:.2f} s")

    def _append_firmware_logs(self, lines: list[str]) -> None:
        for line in lines:
            self.console.appendPlainText(line)
        self.console.moveCursor(QTextCursor.End)

    def _firmware_error(self, text: str) -> None:
        self.console.appendPlainText(f"[RUNNER ERROR] {text}")
        self._set_run_badge("RUNNER ERROR", "error")

    def _runner_ready_changed(self, ready: bool) -> None:
        if ready:
            self._set_run_badge("RUNNING", "running")
        elif not self.paused:
            self._set_run_badge("STOPPED", "error")

    def _update_led_table(self, leds) -> None:
        for row, (r, g, b) in enumerate(leds):
            grb = (g << 16) | (r << 8) | b
            current_ma = 0.7 + ((r + g + b) / 255.0) * 12.0
            values = [str(r), str(g), str(b), f"0x{grb:06X}", f"{current_ma:.1f} mA"]
            for col, value in enumerate(values, start=1):
                self.led_table.item(row, col).setText(value)
                if col in (1, 2, 3):
                    self.led_table.item(row, col).setBackground(QColor(r // 3, g // 3, b // 3))

    def _update_power_ui(self, s: PowerState) -> None:
        good = "good" if s.power_good else "warn"
        self.metrics["v5"].set_value(f"{s.v5:.2f}", "good" if s.v5 >= 4.35 else "bad")
        self.metrics["v3v3"].set_value(f"{s.v3v3:.2f}", "good" if s.v3v3 >= 3.00 else "bad")
        self.metrics["v1v1"].set_value(f"{s.v1v1:.2f}", "good" if s.v1v1 >= 1.00 else "bad")
        self.metrics["usb_current"].set_value(f"{s.usb_current_a * 1000:.0f}", good)
        self.metrics["cable_drop"].set_value(f"{s.cable_drop_v * 1000:.1f}", "good" if s.cable_drop_v < 0.15 else "warn")
        self.metrics["contact_drop"].set_value(f"{s.contact_drop_v * 1000:.1f}", "good" if s.contact_drop_v < 0.10 else "warn")
        self.metrics["led_current"].set_value(f"{s.led_current_a * 1000:.0f}", "neutral")
        self.metrics["u2_power"].set_value(f"{s.u2_power_w * 1000:.0f}", "good" if s.u2_power_w < 0.5 else "warn")
        self.metrics["u2_temp"].set_value(f"{s.u2_temp_c:.1f}", "good" if s.u2_temp_c < 70 else "warn")
        self.power_warning.setText(s.warning)
        self.power_warning.setObjectName("Good" if s.power_good else "Warn")
        self.power_warning.style().unpolish(self.power_warning)
        self.power_warning.style().polish(self.power_warning)

    # ---------- Misc UI handlers ----------

    def _usb_insertion_changed(self, insertion: float) -> None:
        self.insertion_label.setText(f"Insertion depth: {insertion * 100:.0f}%")

    def _usb_state_changed(self, state: str) -> None:
        self._last_usb_state = state
        self.usb_state_label.setText(state)
        object_name = "Good" if state == "CONNECTED" else "Warn" if "ENGAGED" in state or state == "ALIGNED" else "Bad"
        self.usb_state_label.setObjectName(object_name)
        self.usb_state_label.style().unpolish(self.usb_state_label)
        self.usb_state_label.style().polish(self.usb_state_label)
        self._append_event(f"USB-C: {state}")

    def _append_event(self, line: str) -> None:
        self.console.appendPlainText(f"[APP] {line}")

    def reset_firmware(self) -> None:
        self.power.reset()
        self.firmware.reset()
        self._append_event("Firmware reset requested")

    def toggle_pause(self) -> None:
        self.paused = not self.paused
        self.pause_button.setText("Resume" if self.paused else "Pause")
        if self.paused:
            self._set_run_badge("PAUSED", "starting")
        elif self.firmware.ready:
            self._runner_ready_changed(True)

    def _speed_changed(self, text: str) -> None:
        self.speed = float(text.replace("×", ""))

    def clear_faults(self) -> None:
        self.fault_5v.setChecked(False)
        self.fault_3v3.setChecked(False)
        self.fault_1v1.setChecked(False)

    def board_view_fit_delayed(self) -> None:
        QTimer.singleShot(0, self.board_view.fit_board)

    def _source_modified(self) -> None:
        self._update_source_labels()

    def _update_source_labels(self) -> None:
        mark = " *" if self.editor.document().isModified() else ""
        self.firmware_file_label.setText(f"{self.current_source}{mark}")
        self.status_source.setText(f"Firmware: {self.current_source.name}{mark}")

    def show_api_reference(self) -> None:
        QMessageBox.information(
            self,
            "DEV-Brain C++ API",
            "Every program includes devbrain.hpp and implements:\n\n"
            "void setup();\nvoid update(std::uint32_t delta_ms);\n\n"
            "LEDs:\n  devbrain::leds::set(index, r, g, b);\n  devbrain::leds::fill(r, g, b);\n  devbrain::leds::clear();\n\n"
            "Button:\n  devbrain::button::down();\n  devbrain::button::pressed();\n  devbrain::button::released();\n\n"
            "Time/logging:\n  devbrain::millis();\n  devbrain::frame();\n  devbrain::log(\"text\");\n  devbrain::set_status(\"mode\");",
        )

    def show_accuracy(self) -> None:
        text = (self.root / "docs" / "SIMULATION_ACCURACY.md").read_text(encoding="utf-8")
        QMessageBox.information(self, "Simulation accuracy", text[:4000])

    def show_about(self) -> None:
        QMessageBox.about(
            self,
            "About Lamoka1 DEV-Brain Studio",
            "Lamoka1 DEV-Brain Studio 3.0\n\n"
            "A fully local behavioral simulator and C++ firmware workbench for the experimental RP2354A DEV-Brain.\n\n"
            "The simulator never modifies the Lamoka1 repository unless you explicitly save a file there.",
        )


    def keyPressEvent(self, event) -> None:
        if event.key() == Qt.Key_Space and self.center_tabs.currentIndex() == 0 and not event.isAutoRepeat():
            self._board_button_changed(True)
            event.accept()
            return
        super().keyPressEvent(event)

    def keyReleaseEvent(self, event) -> None:
        if event.key() == Qt.Key_Space and self.center_tabs.currentIndex() == 0 and not event.isAutoRepeat():
            self._board_button_changed(False)
            event.accept()
            return
        super().keyReleaseEvent(event)

    def closeEvent(self, event) -> None:
        if self.editor.document().isModified():
            result = QMessageBox.question(self, "Unsaved firmware", "Save the current C++ firmware before closing?", QMessageBox.Save | QMessageBox.Discard | QMessageBox.Cancel)
            if result == QMessageBox.Cancel:
                event.ignore()
                return
            if result == QMessageBox.Save and not self.save_source():
                event.ignore()
                return
        if self._build_process and self._build_process.state() != QProcess.NotRunning:
            try:
                self._build_process.finished.disconnect()
            except (RuntimeError, TypeError):
                pass
            self._build_process.kill()
            self._build_process.waitForFinished(1000)
        self.firmware.stop()
        event.accept()
