from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication

from .main_window import MainWindow
from .theme import APP_STYLE


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--smoke-test", action="store_true")
    args = parser.parse_args()

    root = Path(__file__).resolve().parents[1]
    app = QApplication(sys.argv)
    app.setApplicationName("Lamoka1 DEV-Brain Studio")
    app.setOrganizationName("Flamingo and Cactus")
    app.setStyle("Fusion")
    app.setStyleSheet(APP_STYLE)
    window = MainWindow(root)
    window.show()
    if args.smoke_test:
        QTimer.singleShot(1600, app.quit)
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
