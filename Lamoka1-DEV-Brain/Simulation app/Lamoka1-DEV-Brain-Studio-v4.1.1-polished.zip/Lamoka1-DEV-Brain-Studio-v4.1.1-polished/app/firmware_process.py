from __future__ import annotations

import json
import sys
from pathlib import Path

from PySide6.QtCore import QObject, QProcess, QTimer, Signal


class FirmwareProcess(QObject):
    state_updated = Signal(dict)
    log_lines = Signal(list)
    error = Signal(str)
    ready_changed = Signal(bool)

    def __init__(self, root: Path, parent: QObject | None = None) -> None:
        super().__init__(parent)
        self.root = root
        self.process = QProcess(self)
        self.process.setProcessChannelMode(QProcess.SeparateChannels)
        self.process.readyReadStandardOutput.connect(self._read_stdout)
        self.process.readyReadStandardError.connect(self._read_stderr)
        self.process.errorOccurred.connect(lambda _: self.error.emit(self.process.errorString()))
        self.process.finished.connect(self._finished)
        self._stdout_buffer = ""
        self._outstanding = False
        self._ready = False
        self.last_state: dict = {
            "leds": [[0, 0, 0] for _ in range(10)],
            "uptime_ms": 0,
            "frame": 0,
            "gpio0": 1,
            "power_good": False,
            "status": "Firmware not running",
        }

    @property
    def ready(self) -> bool:
        return self._ready

    def start(self, plugin: Path) -> None:
        self.stop()
        self._stdout_buffer = ""
        self._outstanding = False
        self._set_ready(False)
        self.process.setWorkingDirectory(str(self.root))
        self.process.start(sys.executable, [str(self.root / "runtime" / "runner.py"), str(plugin)])
        if not self.process.waitForStarted(3000):
            self.error.emit(f"Could not start firmware runner: {self.process.errorString()}")

    def stop(self) -> None:
        if self.process.state() != QProcess.NotRunning:
            self._write({"cmd": "shutdown"}, force=True)
            self.process.waitForFinished(500)
            if self.process.state() != QProcess.NotRunning:
                self.process.kill()
                self.process.waitForFinished(1000)
        self._set_ready(False)
        self._outstanding = False

    def reset(self) -> None:
        if self._ready and not self._outstanding:
            self._write({"cmd": "reset"})

    def tick(self, dt_ms: int, gpio0: bool, power_good: bool) -> None:
        if self._ready and not self._outstanding:
            self._write({
                "cmd": "tick",
                "dt_ms": max(1, min(int(dt_ms), 100)),
                "gpio0": bool(gpio0),
                "power_good": bool(power_good),
            })

    def _write(self, payload: dict, *, force: bool = False) -> None:
        if self.process.state() == QProcess.NotRunning:
            return
        self.process.write((json.dumps(payload) + "\n").encode("utf-8"))
        if not force:
            self._outstanding = True

    def _read_stdout(self) -> None:
        self._stdout_buffer += bytes(self.process.readAllStandardOutput()).decode("utf-8", errors="replace")
        while "\n" in self._stdout_buffer:
            line, self._stdout_buffer = self._stdout_buffer.split("\n", 1)
            if not line.strip():
                continue
            try:
                payload = json.loads(line)
            except json.JSONDecodeError:
                self.error.emit(f"Invalid firmware runner response: {line[:240]}")
                continue
            self._outstanding = False
            if not payload.get("ok"):
                self.error.emit(str(payload.get("error", "Firmware runner error")))
                continue
            if payload.get("ready"):
                self._set_ready(True)
            self.last_state = payload
            logs = payload.get("logs") or []
            if logs:
                self.log_lines.emit(logs)
            self.state_updated.emit(payload)

    def _read_stderr(self) -> None:
        text = bytes(self.process.readAllStandardError()).decode("utf-8", errors="replace").strip()
        if text:
            self.error.emit(text)

    def _finished(self, exit_code: int, _status: QProcess.ExitStatus) -> None:
        was_ready = self._ready
        self._set_ready(False)
        self._outstanding = False
        if was_ready and exit_code != 0:
            self.error.emit(f"Firmware runner exited with code {exit_code}")

    def _set_ready(self, value: bool) -> None:
        if self._ready != value:
            self._ready = value
            self.ready_changed.emit(value)
