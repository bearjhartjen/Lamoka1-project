from __future__ import annotations

import math
from collections import deque
from dataclasses import dataclass


@dataclass(slots=True)
class PowerState:
    insertion: float = 0.0
    shell_engaged: bool = False
    contacts_engaged: bool = False
    usb_connected: bool = False
    source_v: float = 5.0
    cable_resistance_ohm: float = 0.20
    contact_resistance_ohm: float = 0.02
    current_limit_a: float = 1.50
    v5: float = 0.0
    v3v3: float = 0.0
    v1v1: float = 0.0
    usb_current_a: float = 0.0
    led_current_a: float = 0.0
    board_current_a: float = 0.0
    cable_drop_v: float = 0.0
    contact_drop_v: float = 0.0
    u2_power_w: float = 0.0
    u2_temp_c: float = 25.0
    power_good: bool = False
    warning: str = "USB-C disconnected"


class PowerModel:
    """Board-level approximation used for diagnostics, not a SPICE solver."""

    def __init__(self) -> None:
        self.state = PowerState()
        self.ambient_c = 25.0
        self.time_s = 0.0
        self.history: deque[tuple[float, float, float, float]] = deque(maxlen=520)
        self._history_accumulator = 0.0

    @staticmethod
    def _approach(value: float, target: float, dt: float, tau: float) -> float:
        if tau <= 0.0:
            return target
        alpha = 1.0 - math.exp(-dt / tau)
        return value + (target - value) * alpha

    @staticmethod
    def estimate_led_current(leds: list[list[int]] | list[tuple[int, int, int]]) -> float:
        # Approximate modern WS2812B current: idle plus roughly 12 mA/channel at 255.
        current = 0.0
        for r, g, b in leds:
            current += 0.0007 + ((r + g + b) / 255.0) * 0.012
        return current

    def reset(self) -> None:
        keep = self.state
        self.state = PowerState(
            insertion=keep.insertion,
            source_v=keep.source_v,
            cable_resistance_ohm=keep.cable_resistance_ohm,
            current_limit_a=keep.current_limit_a,
        )
        self.time_s = 0.0
        self.history.clear()
        self._history_accumulator = 0.0

    def update(
        self,
        dt_s: float,
        leds: list[list[int]] | list[tuple[int, int, int]],
        *,
        insertion: float,
        source_v: float,
        cable_resistance_ohm: float,
        current_limit_a: float,
        fault_5v: bool = False,
        fault_3v3: bool = False,
        fault_1v1: bool = False,
    ) -> PowerState:
        dt_s = max(0.0005, min(float(dt_s), 0.100))
        s = self.state
        self.time_s += dt_s

        s.insertion = max(0.0, min(float(insertion), 1.0))
        s.shell_engaged = s.insertion >= 0.38
        s.contacts_engaged = s.insertion >= 0.82
        s.usb_connected = s.insertion >= 0.94
        s.source_v = float(source_v)
        s.cable_resistance_ohm = max(0.0, float(cable_resistance_ohm))
        s.current_limit_a = max(0.02, float(current_limit_a))
        s.contact_resistance_ohm = 0.015 + max(0.0, 0.94 - s.insertion) * 0.65
        s.led_current_a = self.estimate_led_current(leds)

        # RP2354A + I/O + LDO quiescent + AHCT buffer approximation.
        i3v3 = 0.028
        i5_overhead = 0.004
        requested = s.led_current_a + i3v3 + i5_overhead
        current = min(requested, s.current_limit_a) if s.usb_connected else 0.0
        s.usb_current_a = current
        s.board_current_a = current
        s.cable_drop_v = current * s.cable_resistance_ohm
        s.contact_drop_v = current * s.contact_resistance_ohm

        if s.usb_connected and not fault_5v:
            target_5 = max(0.0, s.source_v - s.cable_drop_v - s.contact_drop_v)
            if requested > s.current_limit_a:
                target_5 *= s.current_limit_a / max(requested, 0.001)
        else:
            target_5 = 0.0

        s.v5 = self._approach(s.v5, target_5, dt_s, 0.006 if target_5 > s.v5 else 0.070)

        # Generic AMS1117 family approximation. Output cannot regulate without headroom.
        target_3v3 = 0.0 if fault_3v3 else min(3.30, max(0.0, s.v5 - 1.02))
        s.v3v3 = self._approach(s.v3v3, target_3v3, dt_s, 0.012 if target_3v3 > s.v3v3 else 0.050)

        target_1v1 = 1.10 if s.v3v3 >= 2.85 and not fault_1v1 else 0.0
        s.v1v1 = self._approach(s.v1v1, target_1v1, dt_s, 0.004 if target_1v1 > s.v1v1 else 0.016)

        s.u2_power_w = max(0.0, (s.v5 - s.v3v3) * i3v3)
        target_temp = self.ambient_c + s.u2_power_w * 68.0
        s.u2_temp_c = self._approach(s.u2_temp_c, target_temp, dt_s, 5.0)
        s.power_good = s.v5 >= 4.35 and s.v3v3 >= 3.00 and s.v1v1 >= 1.00

        if s.insertion < 0.20:
            s.warning = "USB-C plug removed"
        elif not s.shell_engaged:
            s.warning = "USB-C plug not aligned with receptacle"
        elif not s.contacts_engaged:
            s.warning = "USB-C shell engaged; contacts still open"
        elif not s.usb_connected:
            s.warning = "USB-C contacts partially engaged"
        elif fault_5v:
            s.warning = "5 V fault injected"
        elif requested > s.current_limit_a:
            s.warning = "USB source current limit active"
        elif s.v5 < 4.35:
            s.warning = "5 V rail undervoltage"
        elif fault_3v3 or s.v3v3 < 3.00:
            s.warning = "3V3 rail undervoltage"
        elif fault_1v1 or s.v1v1 < 1.00:
            s.warning = "1V1 core rail undervoltage"
        elif s.u2_temp_c > 85.0:
            s.warning = "U2 regulator temperature warning"
        else:
            s.warning = "Power rails nominal"

        self._history_accumulator += dt_s
        if self._history_accumulator >= 0.025:
            self._history_accumulator = 0.0
            self.history.append((self.time_s, s.v5, s.v3v3, s.v1v1))
        return s
