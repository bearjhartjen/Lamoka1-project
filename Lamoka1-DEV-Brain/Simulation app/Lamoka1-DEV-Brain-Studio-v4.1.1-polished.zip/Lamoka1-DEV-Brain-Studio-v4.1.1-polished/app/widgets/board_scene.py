from __future__ import annotations

import json
from pathlib import Path

from PySide6.QtCore import QEasingCurve, QPointF, QRectF, Qt, QVariantAnimation, Signal
from PySide6.QtGui import (
    QColor,
    QImage,
    QLinearGradient,
    QPainter,
    QPainterPath,
    QPen,
    QPixmap,
    QRadialGradient,
)
from PySide6.QtWidgets import (
    QGraphicsDropShadowEffect,
    QGraphicsItem,
    QGraphicsObject,
    QGraphicsPathItem,
    QGraphicsPixmapItem,
    QGraphicsScene,
    QGraphicsView,
)


def _content_crop(pixmap: QPixmap) -> QPixmap:
    """Trim transparent or near-black render margins without touching the PCB.

    KiCad's exported repository render contains a large transparent canvas around
    the board. The old simulator positioned overlays against that whole canvas,
    which is why the LEDs floated above a tiny board. This scans the render once
    and crops it to the visible PCB/component bounds.
    """
    image = pixmap.toImage().convertToFormat(QImage.Format_RGBA8888)
    width, height = image.width(), image.height()
    if width < 8 or height < 8:
        return pixmap

    raw = memoryview(image.constBits()).cast("B")
    stride = image.bytesPerLine()

    # Estimate the exported-canvas background from the four corners.
    corners: list[tuple[int, int, int, int]] = []
    for x, y in ((0, 0), (width - 1, 0), (0, height - 1), (width - 1, height - 1)):
        i = y * stride + x * 4
        corners.append(tuple(int(raw[i + n]) for n in range(4)))
    bg = tuple(sorted(c[n] for c in corners)[len(corners) // 2] for n in range(4))
    transparent_canvas = max(c[3] for c in corners) < 20

    step = 2 if max(width, height) > 1800 else 1
    left, top, right, bottom = width, height, -1, -1
    for y in range(0, height, step):
        row = y * stride
        for x in range(0, width, step):
            i = row + x * 4
            r, g, b, a = (int(raw[i]), int(raw[i + 1]), int(raw[i + 2]), int(raw[i + 3]))
            if a <= 8:
                continue
            if transparent_canvas:
                visible = True
            else:
                color_delta = abs(r - bg[0]) + abs(g - bg[1]) + abs(b - bg[2])
                visible = color_delta > 24 or max(r, g, b) > 24
            if visible:
                left = min(left, x)
                top = min(top, y)
                right = max(right, x)
                bottom = max(bottom, y)

    if right < left or bottom < top:
        return pixmap

    # Add a small safety pad for shadows, connector overhang, and rounded edges.
    pad_x = max(8, int((right - left + 1) * 0.012))
    pad_y = max(6, int((bottom - top + 1) * 0.025))
    left = max(0, left - pad_x)
    top = max(0, top - pad_y)
    right = min(width - 1, right + pad_x)
    bottom = min(height - 1, bottom + pad_y)

    crop = QRectF(left, top, right - left + 1, bottom - top + 1).toAlignedRect()
    # Reject a bogus crop, but accept the large-margin case this function targets.
    if crop.width() < width * 0.12 or crop.height() < height * 0.12:
        return pixmap
    return QPixmap.fromImage(image.copy(crop))


def _detect_blue_led_packages(pixmap: QPixmap) -> list[QRectF]:
    """Locate the ten blue WS2812 lenses in the official top-down render.

    The repository render already shows every LED lens in blue. Detecting those
    pixels means overlays remain exact even if KiCad exports a different canvas
    size or the render is later regenerated.
    """
    image = pixmap.toImage().convertToFormat(QImage.Format_RGBA8888)
    width, height = image.width(), image.height()
    raw = memoryview(image.constBits()).cast("B")
    stride = image.bytesPerLine()
    y_limit = max(1, int(height * 0.46))
    counts = [0] * width
    y_min = [height] * width
    y_max = [-1] * width
    for y in range(y_limit):
        row = y * stride
        for x in range(width):
            i = row + x * 4
            r, g, b, a = int(raw[i]), int(raw[i + 1]), int(raw[i + 2]), int(raw[i + 3])
            if a > 20 and b >= 85 and b > r + 22 and b > g + 8:
                counts[x] += 1
                y_min[x] = min(y_min[x], y)
                y_max[x] = max(y_max[x], y)

    threshold = max(2, int(height * 0.012))
    runs: list[tuple[int, int]] = []
    start = None
    for x, count in enumerate(counts + [0]):
        if count >= threshold and start is None:
            start = x
        elif count < threshold and start is not None:
            if x - start >= max(3, int(width * 0.004)):
                runs.append((start, x - 1))
            start = None

    candidates: list[QRectF] = []
    for x0, x1 in runs:
        ys0 = [y_min[x] for x in range(x0, x1 + 1) if y_min[x] < height]
        ys1 = [y_max[x] for x in range(x0, x1 + 1) if y_max[x] >= 0]
        if not ys0 or not ys1:
            continue
        yy0, yy1 = min(ys0), max(ys1)
        w, h = x1 - x0 + 1, yy1 - yy0 + 1
        if w < width * 0.008 or w > width * 0.085:
            continue
        if h < height * 0.018 or h > height * 0.22:
            continue
        candidates.append(QRectF(x0, yy0, w, h))

    if len(candidates) < 10:
        return []

    # The ten packages form the dominant evenly spaced horizontal run. Search
    # every ten-candidate window and pick the one with the lowest spacing error.
    candidates.sort(key=lambda rect: rect.center().x())
    best: list[QRectF] = []
    best_error = float("inf")
    for start_index in range(0, len(candidates) - 9):
        group = candidates[start_index:start_index + 10]
        centers = [rect.center().x() for rect in group]
        spacings = [b - a for a, b in zip(centers, centers[1:])]
        mean = sum(spacings) / len(spacings)
        if mean <= 0:
            continue
        spacing_error = sum(abs(v - mean) for v in spacings) / (mean * len(spacings))
        y_centers = [rect.center().y() for rect in group]
        y_mean = sum(y_centers) / len(y_centers)
        y_error = sum(abs(v - y_mean) for v in y_centers) / max(1.0, height * len(y_centers))
        error = spacing_error + y_error * 4.0
        if error < best_error:
            best_error = error
            best = group
    if best_error > 0.30:
        return []

    # Expand from the blue die/lens to the visible package lens area.
    expanded: list[QRectF] = []
    for rect in best:
        pad_x = rect.width() * 0.30
        pad_y = rect.height() * 0.30
        expanded.append(rect.adjusted(-pad_x, -pad_y, pad_x, pad_y))
    return expanded


class LedOverlay(QGraphicsObject):
    """Light emitted from the real D1-D10 package locations.

    No surrogate LED row is drawn. When off, this item paints nothing and the
    actual package from the PCB render remains visible underneath.
    """

    def __init__(self, rect: QRectF, label: str, parent: QGraphicsItem | None = None) -> None:
        super().__init__(parent)
        self._rect = rect
        self._color = QColor(0, 0, 0)
        self.label = label
        self.setZValue(30)
        self.setAcceptedMouseButtons(Qt.NoButton)

    def boundingRect(self) -> QRectF:
        margin = max(self._rect.width(), self._rect.height()) * 0.62
        return self._rect.adjusted(-margin, -margin, margin, margin)

    def set_rgb(self, r: int, g: int, b: int) -> None:
        next_color = QColor(max(0, min(255, int(r))), max(0, min(255, int(g))), max(0, min(255, int(b))))
        if next_color != self._color:
            self._color = next_color
            self.update()

    @staticmethod
    def _display_channel(value: int) -> int:
        # Firmware often intentionally drives values below 64. Boost those for a
        # screen representation while preserving relative channel brightness.
        return min(255, int((value / 255.0) ** 0.62 * 255.0))

    def paint(self, painter: QPainter, _option, _widget=None) -> None:
        r, g, b, _ = self._color.getRgb()
        if max(r, g, b) <= 0:
            return

        painter.setRenderHint(QPainter.Antialiasing)
        display = QColor(self._display_channel(r), self._display_channel(g), self._display_channel(b))
        center = self._rect.center()
        radius = max(self._rect.width(), self._rect.height()) * 0.75

        # Controlled package-local bloom, not a detached floating orb.
        glow = QRadialGradient(center, radius)
        glow.setColorAt(0.0, QColor(display.red(), display.green(), display.blue(), 180))
        glow.setColorAt(0.42, QColor(display.red(), display.green(), display.blue(), 75))
        glow.setColorAt(1.0, QColor(display.red(), display.green(), display.blue(), 0))
        painter.setPen(Qt.NoPen)
        painter.setBrush(glow)
        painter.drawEllipse(center, radius, radius)

        lens = self._rect.adjusted(self._rect.width() * 0.08, self._rect.height() * 0.08,
                                   -self._rect.width() * 0.08, -self._rect.height() * 0.08)
        lens_grad = QRadialGradient(
            lens.center() - QPointF(lens.width() * 0.14, lens.height() * 0.16),
            max(lens.width(), lens.height()),
        )
        lens_grad.setColorAt(0.0, QColor(255, 255, 255, 225))
        lens_grad.setColorAt(0.18, display.lighter(150))
        lens_grad.setColorAt(0.68, QColor(display.red(), display.green(), display.blue(), 225))
        lens_grad.setColorAt(1.0, QColor(display.darker(185).red(), display.darker(185).green(), display.darker(185).blue(), 220))
        painter.setPen(QPen(QColor(display.red(), display.green(), display.blue(), 190), max(0.8, lens.width() * 0.025)))
        painter.setBrush(lens_grad)
        painter.drawRoundedRect(lens, lens.width() * 0.15, lens.height() * 0.15)


class BoardButtonItem(QGraphicsObject):
    pressed_changed = Signal(bool)

    def __init__(self, rect: QRectF, parent: QGraphicsItem | None = None) -> None:
        super().__init__(parent)
        self._rect = rect
        self._pressed = False
        self.setAcceptedMouseButtons(Qt.LeftButton)
        self.setCursor(Qt.PointingHandCursor)
        self.setZValue(40)
        self.setToolTip("SW1 / GPIO0 / BOOTSEL\nClick and hold the actual board switch")

    def boundingRect(self) -> QRectF:
        return self._rect.adjusted(-3, -3, 3, 3)

    def paint(self, painter: QPainter, _option, _widget=None) -> None:
        # The unpressed switch is already in the actual render. Only draw its
        # physical travel/depression while pressed.
        if not self._pressed:
            return
        painter.setRenderHint(QPainter.Antialiasing)
        cap = self._rect.adjusted(self._rect.width() * 0.17, self._rect.height() * 0.17,
                                  -self._rect.width() * 0.17, -self._rect.height() * 0.17)
        painter.setPen(QPen(QColor(0, 0, 0, 185), max(1.0, cap.width() * 0.035)))
        painter.setBrush(QColor(5, 8, 10, 125))
        painter.drawRoundedRect(cap.translated(0, cap.height() * 0.07), cap.width() * 0.2, cap.height() * 0.2)
        painter.setPen(QPen(QColor(87, 220, 255, 130), max(0.8, cap.width() * 0.018)))
        painter.setBrush(Qt.NoBrush)
        painter.drawRoundedRect(self._rect.adjusted(1, 1, -1, -1), self._rect.width() * 0.13, self._rect.height() * 0.13)

    def mousePressEvent(self, event) -> None:
        if event.button() == Qt.LeftButton:
            self._set_pressed(True)
            event.accept()
        else:
            event.ignore()

    def mouseReleaseEvent(self, event) -> None:
        if self._pressed:
            self._set_pressed(False)
            event.accept()
        else:
            event.ignore()

    def _set_pressed(self, value: bool) -> None:
        if self._pressed != value:
            self._pressed = value
            self.update()
            self.pressed_changed.emit(value)


class UsbPlugItem(QGraphicsObject):
    insertion_changed = Signal(float)
    connection_state_changed = Signal(str)

    def __init__(self, port_rect: QRectF, board_rect: QRectF) -> None:
        super().__init__()
        self.port_rect = port_rect
        self.board_rect = board_rect
        port_h = max(34.0, port_rect.height())

        shell_h = port_h * 0.63
        shell_w = shell_h * 1.28
        body_h = shell_h * 1.55
        body_w = body_h * 1.40
        self._body = QRectF(0, 0, body_w, body_h)
        self._shell = QRectF(body_w * 0.80, (body_h - shell_h) / 2.0, shell_w, shell_h)
        self._tip_local_x = self._shell.right()
        self.target_y = port_rect.center().y()

        # Fully inserted means the shell tip is behind the board render, inside
        # the receptacle. Because this item is under the PCB image, that overlap
        # is visually occluded like a real connector.
        insertion_depth = max(port_rect.width() * 0.68, shell_w * 0.40)
        self._connected_x = port_rect.left() + insertion_depth - self._tip_local_x
        self._disconnected_x = board_rect.left() - body_w - shell_w - board_rect.width() * 0.045
        self._home_y = self.target_y - body_h / 2.0

        self._drag_start = QPointF()
        self._insertion = 0.0
        self._state = "DISCONNECTED"
        self._animation: QVariantAnimation | None = None
        self.setPos(self._disconnected_x, self._home_y)
        self.setAcceptedMouseButtons(Qt.LeftButton)
        self.setCursor(Qt.OpenHandCursor)
        self.setZValue(6)  # below the PCB render: the shell truly slides into it
        self.setToolTip("Drag the USB-C plug into the real receptacle")

    def boundingRect(self) -> QRectF:
        return self._body.united(self._shell).adjusted(-8, -8, 8, 8)

    @property
    def insertion(self) -> float:
        return self._insertion

    def paint(self, painter: QPainter, _option, _widget=None) -> None:
        painter.setRenderHint(QPainter.Antialiasing)

        body_grad = QLinearGradient(self._body.topLeft(), self._body.bottomLeft())
        body_grad.setColorAt(0.0, QColor("#30363d"))
        body_grad.setColorAt(0.22, QColor("#161a1f"))
        body_grad.setColorAt(0.66, QColor("#07090b"))
        body_grad.setColorAt(1.0, QColor("#242a30"))
        painter.setPen(QPen(QColor("#59636d"), max(1.0, self._body.height() * 0.018)))
        painter.setBrush(body_grad)
        painter.drawRoundedRect(self._body, self._body.height() * 0.20, self._body.height() * 0.20)

        # Molded strain relief.
        painter.setPen(QPen(QColor(70, 79, 87), max(1.0, self._body.height() * 0.018)))
        for frac in (0.16, 0.24, 0.32):
            x = self._body.left() + self._body.width() * frac
            painter.drawLine(QPointF(x, self._body.top() + self._body.height() * 0.13),
                             QPointF(x, self._body.bottom() - self._body.height() * 0.13))

        shell_grad = QLinearGradient(self._shell.topLeft(), self._shell.bottomLeft())
        shell_grad.setColorAt(0.0, QColor("#f0f1ef"))
        shell_grad.setColorAt(0.20, QColor("#9ca3a7"))
        shell_grad.setColorAt(0.54, QColor("#e5e6e3"))
        shell_grad.setColorAt(1.0, QColor("#6e767b"))
        painter.setPen(QPen(QColor("#d9dcdd"), max(0.9, self._shell.height() * 0.025)))
        painter.setBrush(shell_grad)
        painter.drawRoundedRect(self._shell, self._shell.height() * 0.20, self._shell.height() * 0.20)

        opening = self._shell.adjusted(self._shell.width() * 0.20, self._shell.height() * 0.20,
                                       -self._shell.width() * 0.05, -self._shell.height() * 0.20)
        painter.setPen(QPen(QColor("#34393c"), max(0.8, self._shell.height() * 0.02)))
        painter.setBrush(QColor("#101418"))
        painter.drawRoundedRect(opening, opening.height() * 0.23, opening.height() * 0.23)
        painter.setPen(QPen(QColor("#caa94f"), max(0.7, self._shell.height() * 0.018)))
        for i in range(6):
            x = opening.left() + opening.width() * (0.18 + i * 0.12)
            painter.drawLine(QPointF(x, opening.top() + opening.height() * 0.18),
                             QPointF(x, opening.bottom() - opening.height() * 0.18))

        # Tiny molded-cable indicator, deliberately subtle.
        painter.setPen(Qt.NoPen)
        painter.setBrush(QColor("#3fb950") if self._insertion >= 0.94 else QColor("#2f81f7"))
        painter.drawEllipse(QPointF(self._body.right() - self._body.width() * 0.25, self._body.center().y()),
                            self._body.height() * 0.035, self._body.height() * 0.035)

    def mousePressEvent(self, event) -> None:
        self.setCursor(Qt.ClosedHandCursor)
        self._drag_start = event.scenePos() - self.pos()
        if self._animation:
            self._animation.stop()
        event.accept()

    def mouseMoveEvent(self, event) -> None:
        next_pos = event.scenePos() - self._drag_start
        x = max(self._disconnected_x - self.board_rect.width() * 0.035,
                min(self._connected_x + self.port_rect.width() * 0.12, next_pos.x()))
        y_tolerance = self.port_rect.height() * 1.35
        y = max(self._home_y - y_tolerance, min(self._home_y + y_tolerance, next_pos.y()))
        self.setPos(x, y)
        self._recalculate()
        event.accept()

    def mouseReleaseEvent(self, event) -> None:
        self.setCursor(Qt.OpenHandCursor)
        aligned = abs((self.y() + self._body.center().y()) - self.target_y) <= self.port_rect.height() * 0.48
        if aligned and self._insertion >= 0.44:
            self._animate_to(QPointF(self._connected_x, self._home_y))
        else:
            self._animate_to(QPointF(self._disconnected_x, self._home_y))
        event.accept()

    def toggle(self) -> None:
        self._animate_to(QPointF(self._disconnected_x, self._home_y) if self._insertion >= 0.5
                         else QPointF(self._connected_x, self._home_y))

    def connect_plug(self) -> None:
        self._animate_to(QPointF(self._connected_x, self._home_y))

    def disconnect_plug(self) -> None:
        self._animate_to(QPointF(self._disconnected_x, self._home_y))

    def _animate_to(self, target: QPointF) -> None:
        if self._animation:
            self._animation.stop()
        start = self.pos()
        animation = QVariantAnimation(self)
        animation.setDuration(300)
        animation.setStartValue(0.0)
        animation.setEndValue(1.0)
        animation.setEasingCurve(QEasingCurve.OutCubic)

        def step(t: float) -> None:
            self.setPos(start + (target - start) * float(t))
            self._recalculate()

        animation.valueChanged.connect(step)
        animation.finished.connect(self._recalculate)
        self._animation = animation
        animation.start()

    def _recalculate(self) -> None:
        plug_tip = self.x() + self._tip_local_x
        plug_center_y = self.y() + self._body.center().y()
        aligned = abs(plug_center_y - self.target_y) <= self.port_rect.height() * 0.48

        mouth_x = self.port_rect.left()
        full_x = self.port_rect.left() + max(self.port_rect.width() * 0.68, self._shell.width() * 0.40)
        raw = (plug_tip - mouth_x) / max(1.0, full_x - mouth_x)
        insertion = max(0.0, min(1.0, raw)) if aligned else max(0.0, min(0.18, raw))
        if abs(insertion - self._insertion) > 0.002:
            self._insertion = insertion
            self.insertion_changed.emit(insertion)

        if not aligned:
            state = "MISALIGNED"
        elif insertion < 0.04:
            state = "DISCONNECTED"
        elif insertion < 0.25:
            state = "ALIGNED"
        elif insertion < 0.70:
            state = "SHELL ENGAGED"
        elif insertion < 0.94:
            state = "CONTACTS ENGAGED"
        else:
            state = "CONNECTED"
        if state != self._state:
            self._state = state
            self.connection_state_changed.emit(state)
        self.update()


class BoardGraphicsView(QGraphicsView):
    button_changed = Signal(bool)
    usb_insertion_changed = Signal(float)
    usb_state_changed = Signal(str)

    def __init__(self, root: Path, parent=None) -> None:
        super().__init__(parent)
        self.root = root
        self.setRenderHints(QPainter.Antialiasing | QPainter.SmoothPixmapTransform | QPainter.TextAntialiasing)
        self.setDragMode(QGraphicsView.ScrollHandDrag)
        self.setTransformationAnchor(QGraphicsView.AnchorUnderMouse)
        self.setResizeAnchor(QGraphicsView.AnchorViewCenter)
        self.setBackgroundBrush(QColor("#060a0f"))
        self.setFrameShape(QGraphicsView.NoFrame)
        self.scene_obj = QGraphicsScene(self)
        self.setScene(self.scene_obj)
        self.led_items: list[LedOverlay] = []
        self.board_item: QGraphicsPixmapItem | None = None
        self.button_item: BoardButtonItem | None = None
        self.usb_plug: UsbPlugItem | None = None
        self.cable_item = QGraphicsPathItem()
        self.cable_item.setZValue(2)
        self.scene_obj.addItem(self.cable_item)
        self._board_rect = QRectF()
        self._auto_fit = True
        self._load_board()

    def _load_board(self) -> None:
        actual = self.root / "assets" / "actual-devbrain.png"
        fallback = self.root / "assets" / "fallback-board.png"
        image_path = actual if actual.exists() else fallback
        if not image_path.exists():
            raise FileNotFoundError("No DEV-Brain board image was found")
        pixmap = QPixmap(str(image_path))
        if pixmap.isNull():
            raise RuntimeError(f"Could not load board image: {image_path}")

        pixmap = _content_crop(pixmap)
        detected_source_leds = _detect_blue_led_packages(pixmap) if image_path == actual else []
        source_width = max(1, pixmap.width())
        source_height = max(1, pixmap.height())
        target_width = 1500.0
        target_height = target_width * source_height / source_width
        scaled = pixmap.scaled(int(target_width), int(target_height), Qt.KeepAspectRatio, Qt.SmoothTransformation)

        self.board_item = self.scene_obj.addPixmap(scaled)
        self.board_item.setPos(330, 95)
        self.board_item.setZValue(10)
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(42)
        shadow.setOffset(0, 18)
        shadow.setColor(QColor(0, 0, 0, 185))
        self.board_item.setGraphicsEffect(shadow)
        self._board_rect = QRectF(self.board_item.pos(), scaled.size())

        layout = json.loads((self.root / "assets" / "board-layout.json").read_text(encoding="utf-8"))
        button = [float(v) for v in layout["button"]]
        usb = [float(v) for v in layout["usb_port"]]

        local_led_rects: list[QRectF] = []
        if detected_source_leds:
            sx = self._board_rect.width() / source_width
            sy = self._board_rect.height() / source_height
            for source_rect in detected_source_leds:
                local_led_rects.append(QRectF(source_rect.x() * sx, source_rect.y() * sy,
                                               source_rect.width() * sx, source_rect.height() * sy))
        else:
            led_x = [float(point[0]) for point in layout["leds"]]
            led_y = float(layout["leds"][0][1])
            led_w, led_h = (float(v) for v in layout["led_size"])
            for nx in led_x:
                center = QPointF(nx * self._board_rect.width(), led_y * self._board_rect.height())
                local_led_rects.append(QRectF(center.x() - led_w * self._board_rect.width() / 2,
                                              center.y() - led_h * self._board_rect.height() / 2,
                                              led_w * self._board_rect.width(),
                                              led_h * self._board_rect.height()))

        for index, rect in enumerate(local_led_rects):
            item = LedOverlay(rect, f"D{index + 1}", self.board_item)
            item.setToolTip(f"D{index + 1} WS2812B")
            self.led_items.append(item)

        if detected_source_leds and len(local_led_rects) >= 2:
            spacing = local_led_rects[1].center().x() - local_led_rects[0].center().x()
            first = local_led_rects[0]
            button_center = QPointF(first.center().x() - spacing * 1.43, first.center().y())
            button_size = max(first.height() * 1.18, spacing * 0.78)
            button_rect = QRectF(button_center.x() - button_size / 2,
                                 button_center.y() - button_size / 2,
                                 button_size, button_size)
        else:
            bx, by, bw, bh = button
            button_rect = QRectF((bx - bw / 2) * self._board_rect.width(),
                                 (by - bh / 2) * self._board_rect.height(),
                                 bw * self._board_rect.width(), bh * self._board_rect.height())
        self.button_item = BoardButtonItem(button_rect, self.board_item)
        self.button_item.pressed_changed.connect(self.button_changed)

        px, py, pw, ph = usb
        port_rect = QRectF(self._board_rect.left() + px * self._board_rect.width(),
                           self._board_rect.top() + py * self._board_rect.height(),
                           pw * self._board_rect.width(), ph * self._board_rect.height())
        self.usb_plug = UsbPlugItem(port_rect, self._board_rect)
        self.usb_plug.insertion_changed.connect(self._plug_moved)
        self.usb_plug.connection_state_changed.connect(self.usb_state_changed)
        self.scene_obj.addItem(self.usb_plug)

        left_margin = max(360.0, self._board_rect.width() * 0.24)
        self.scene_obj.setSceneRect(self._board_rect.adjusted(-left_margin, -self._board_rect.height() * 0.09,
                                                              self._board_rect.width() * 0.025,
                                                              self._board_rect.height() * 0.09))
        self.fit_board()
        self._update_cable()

    def fit_board(self) -> None:
        self._auto_fit = True
        self.fitInView(self.scene_obj.sceneRect(), Qt.KeepAspectRatio)

    def wheelEvent(self, event) -> None:
        if event.modifiers() & Qt.ControlModifier:
            factor = 1.16 if event.angleDelta().y() > 0 else 1 / 1.16
            self._auto_fit = False
            self.scale(factor, factor)
            event.accept()
        else:
            super().wheelEvent(event)

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        if self._auto_fit:
            self.fitInView(self.scene_obj.sceneRect(), Qt.KeepAspectRatio)

    def mouseDoubleClickEvent(self, event) -> None:
        self.fit_board()
        event.accept()

    def set_leds(self, leds: list[list[int]] | list[tuple[int, int, int]]) -> None:
        for item, rgb in zip(self.led_items, leds, strict=False):
            item.set_rgb(*rgb)

    def set_button_pressed(self, pressed: bool) -> None:
        if self.button_item:
            self.button_item._set_pressed(pressed)

    def toggle_usb(self) -> None:
        if self.usb_plug:
            self.usb_plug.toggle()

    def connect_usb(self) -> None:
        if self.usb_plug:
            self.usb_plug.connect_plug()

    def disconnect_usb(self) -> None:
        if self.usb_plug:
            self.usb_plug.disconnect_plug()

    @property
    def usb_insertion(self) -> float:
        return self.usb_plug.insertion if self.usb_plug else 0.0

    def _plug_moved(self, insertion: float) -> None:
        self._update_cable()
        self.usb_insertion_changed.emit(insertion)

    def _update_cable(self) -> None:
        if not self.usb_plug:
            return
        plug_left = self.usb_plug.mapToScene(QPointF(self.usb_plug.boundingRect().left(), self.usb_plug._body.center().y()))
        start = QPointF(self.scene_obj.sceneRect().left() - 45, plug_left.y())
        path = QPainterPath(start)
        c1 = QPointF(start.x() + 115, start.y())
        c2 = QPointF(plug_left.x() - 72, plug_left.y())
        path.cubicTo(c1, c2, plug_left)
        self.cable_item.setPath(path)
        cable_width = max(22.0, self._board_rect.height() * 0.055)
        self.cable_item.setPen(QPen(QColor("#171b20"), cable_width, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
