from __future__ import annotations

from collections import deque

from PySide6.QtCore import QRectF, Qt
from PySide6.QtGui import QColor, QFont, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import QWidget


class PowerGraph(QWidget):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setMinimumHeight(190)
        self.history = []

    def set_history(self, history) -> None:
        self.history = list(history)
        self.update()

    def paintEvent(self, _event) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.fillRect(self.rect(), QColor("#090d12"))
        area = QRectF(44, 14, max(10, self.width() - 58), max(10, self.height() - 38))
        painter.setPen(QPen(QColor("#26313d"), 1))
        for v in range(6):
            y = area.bottom() - area.height() * v / 5.0
            painter.drawLine(area.left(), y, area.right(), y)
            painter.setPen(QColor("#7d8da1"))
            painter.drawText(8, int(y + 4), f"{v}V")
            painter.setPen(QPen(QColor("#26313d"), 1))
        if len(self.history) < 2:
            return
        t0 = self.history[0][0]
        t1 = self.history[-1][0]
        span = max(0.001, t1 - t0)
        series = [(1, QColor("#46d9ff")), (2, QColor("#55d66b")), (3, QColor("#e3b341"))]
        for index, color in series:
            path = QPainterPath()
            for n, sample in enumerate(self.history):
                x = area.left() + (sample[0] - t0) / span * area.width()
                y = area.bottom() - max(0.0, min(5.0, sample[index])) / 5.0 * area.height()
                if n == 0:
                    path.moveTo(x, y)
                else:
                    path.lineTo(x, y)
            painter.setPen(QPen(color, 1.7))
            painter.drawPath(path)


class GpioTrace(QWidget):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setMinimumHeight(180)
        self.leds = [[0, 0, 0] for _ in range(10)]

    def set_leds(self, leds) -> None:
        self.leds = [list(x) for x in leds]
        self.update()

    @staticmethod
    def _bits(leds) -> list[int]:
        bits: list[int] = []
        for r, g, b in leds:
            word = (g << 16) | (r << 8) | b
            bits.extend((word >> shift) & 1 for shift in range(23, -1, -1))
        return bits[:96]

    def paintEvent(self, _event) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.fillRect(self.rect(), QColor("#090d12"))
        area = QRectF(52, 24, max(10, self.width() - 72), max(10, self.height() - 58))
        painter.setPen(QColor("#7d8da1"))
        painter.drawText(8, int(area.top() + 5), "3.3V")
        painter.drawText(19, int(area.bottom() + 4), "0V")
        painter.setPen(QPen(QColor("#26313d"), 1))
        painter.drawLine(area.left(), area.top(), area.right(), area.top())
        painter.drawLine(area.left(), area.bottom(), area.right(), area.bottom())
        bits = self._bits(self.leds)
        if not bits:
            return
        step = area.width() / len(bits)
        path = QPainterPath()
        y = area.top() if bits[0] else area.bottom()
        path.moveTo(area.left(), y)
        for i, bit in enumerate(bits):
            x = area.left() + i * step
            next_y = area.top() if bit else area.bottom()
            path.lineTo(x, y)
            path.lineTo(x, next_y)
            path.lineTo(x + step, next_y)
            y = next_y
        painter.setPen(QPen(QColor("#55d66b"), 1.4))
        painter.drawPath(path)
        painter.setPen(QColor("#7d8da1"))
        painter.drawText(int(area.left()), self.height() - 10, "Conceptual GPIO11 WS2812 waveform · 800 kHz")
