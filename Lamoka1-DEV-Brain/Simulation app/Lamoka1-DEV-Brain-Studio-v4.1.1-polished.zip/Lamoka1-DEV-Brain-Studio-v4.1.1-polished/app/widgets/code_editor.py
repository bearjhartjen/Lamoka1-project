from __future__ import annotations

import re
from pathlib import Path

from PySide6.QtCore import QRegularExpression, Qt, Signal
from PySide6.QtGui import QColor, QFont, QSyntaxHighlighter, QTextCharFormat, QTextDocument
from PySide6.QtWidgets import QPlainTextEdit


class CppHighlighter(QSyntaxHighlighter):
    def __init__(self, document: QTextDocument) -> None:
        super().__init__(document)
        self.rules: list[tuple[QRegularExpression, QTextCharFormat]] = []

        def fmt(color: str, *, bold: bool = False, italic: bool = False) -> QTextCharFormat:
            value = QTextCharFormat()
            value.setForeground(QColor(color))
            value.setFontWeight(QFont.Bold if bold else QFont.Normal)
            value.setFontItalic(italic)
            return value

        keyword = fmt("#ff7b72", bold=True)
        type_fmt = fmt("#79c0ff")
        function_fmt = fmt("#d2a8ff")
        string_fmt = fmt("#a5d6ff")
        number_fmt = fmt("#79c0ff")
        preprocessor_fmt = fmt("#ffa657")
        comment_fmt = fmt("#8b949e", italic=True)

        keywords = [
            "alignas", "alignof", "and", "asm", "auto", "bool", "break", "case", "catch",
            "char", "class", "const", "constexpr", "continue", "default", "delete", "do",
            "double", "else", "enum", "explicit", "extern", "false", "float", "for", "friend",
            "if", "inline", "int", "long", "namespace", "new", "noexcept", "nullptr", "operator",
            "or", "private", "protected", "public", "return", "short", "signed", "sizeof", "static",
            "struct", "switch", "template", "this", "throw", "true", "try", "typedef", "typename",
            "union", "unsigned", "using", "virtual", "void", "volatile", "while",
        ]
        self.rules.append((QRegularExpression(r"\b(?:" + "|".join(keywords) + r")\b"), keyword))
        self.rules.append((QRegularExpression(r"\b(?:std::)?(?:uint\d+_t|int\d+_t|string|array|vector|Rgb)\b"), type_fmt))
        self.rules.append((QRegularExpression(r"\b[A-Za-z_][A-Za-z0-9_]*(?=\s*\()"), function_fmt))
        self.rules.append((QRegularExpression(r"\b(?:0x[0-9A-Fa-f]+|\d+(?:\.\d+)?)\b"), number_fmt))
        self.rules.append((QRegularExpression(r'"(?:\\.|[^"\\])*"'), string_fmt))
        self.rules.append((QRegularExpression(r"'(?:\\.|[^'\\])'"), string_fmt))
        self.rules.append((QRegularExpression(r"^\s*#.*$"), preprocessor_fmt))
        self.rules.append((QRegularExpression(r"//[^\n]*"), comment_fmt))
        self.comment_format = comment_fmt

    def highlightBlock(self, text: str) -> None:
        for pattern, text_format in self.rules:
            iterator = pattern.globalMatch(text)
            while iterator.hasNext():
                match = iterator.next()
                self.setFormat(match.capturedStart(), match.capturedLength(), text_format)

        self.setCurrentBlockState(0)
        start = 0 if self.previousBlockState() != 1 else 0
        if self.previousBlockState() != 1:
            start = text.find("/*")
        while start >= 0:
            end = text.find("*/", start + 2)
            if end < 0:
                self.setCurrentBlockState(1)
                length = len(text) - start
            else:
                length = end - start + 2
            self.setFormat(start, length, self.comment_format)
            if end < 0:
                break
            start = text.find("/*", start + length)


class CodeEditor(QPlainTextEdit):
    file_dropped = Signal(Path)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("CodeEditor")
        self.setLineWrapMode(QPlainTextEdit.NoWrap)
        self.setTabStopDistance(32)
        self.setAcceptDrops(True)
        self.highlighter = CppHighlighter(self.document())
        font = QFont("JetBrains Mono")
        if not font.exactMatch():
            font = QFont("Fira Code")
        if not font.exactMatch():
            font = QFont("monospace")
        font.setStyleHint(QFont.Monospace)
        font.setPointSize(10)
        self.setFont(font)

    def keyPressEvent(self, event) -> None:
        if event.key() == Qt.Key_Tab:
            self.insertPlainText("    ")
            event.accept()
            return
        super().keyPressEvent(event)

    def dragEnterEvent(self, event) -> None:
        urls = event.mimeData().urls()
        if urls and Path(urls[0].toLocalFile()).suffix.lower() in {".cpp", ".cc", ".cxx"}:
            event.acceptProposedAction()
        else:
            super().dragEnterEvent(event)

    def dropEvent(self, event) -> None:
        urls = event.mimeData().urls()
        if urls:
            path = Path(urls[0].toLocalFile())
            if path.suffix.lower() in {".cpp", ".cc", ".cxx"}:
                self.file_dropped.emit(path)
                event.acceptProposedAction()
                return
        super().dropEvent(event)
