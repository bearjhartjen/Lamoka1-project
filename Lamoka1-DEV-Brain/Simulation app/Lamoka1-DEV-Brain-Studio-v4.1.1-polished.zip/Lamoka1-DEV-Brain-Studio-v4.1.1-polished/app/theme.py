from __future__ import annotations

APP_STYLE = r"""
QWidget {
    background: #0b1016;
    color: #e8eef5;
    font-family: Inter, Noto Sans, sans-serif;
    font-size: 10.5pt;
}
QMainWindow, QDialog { background: #0b1016; }
QFrame#HeaderCard {
    background: #121a23;
    border: 1px solid #263445;
    border-radius: 10px;
}
QFrame#Panel, QGroupBox {
    background: #121a23;
    border: 1px solid #263445;
    border-radius: 9px;
}
QGroupBox {
    margin-top: 14px;
    padding: 15px 11px 11px 11px;
    font-weight: 750;
}
QGroupBox::title {
    subcontrol-origin: margin;
    left: 11px;
    padding: 0 6px;
    color: #f4f7fb;
}
QPushButton, QToolButton {
    background: #1b2734;
    border: 1px solid #35485d;
    border-radius: 7px;
    padding: 8px 12px;
    color: #f4f7fb;
}
QPushButton:hover, QToolButton:hover { background: #243447; border-color: #55708d; }
QPushButton:pressed, QToolButton:pressed { background: #15202b; }
QPushButton:disabled { color: #657487; background: #131b24; border-color: #24303e; }
QPushButton#PrimaryButton { background: #24743a; border-color: #35a853; font-weight: 750; }
QPushButton#PrimaryButton:hover { background: #2e8d47; }
QPushButton#DangerButton { background: #3c2027; border-color: #86404b; }
QLineEdit, QPlainTextEdit, QTextEdit, QComboBox, QSpinBox, QDoubleSpinBox {
    background: #070b10;
    border: 1px solid #2d3b4c;
    border-radius: 7px;
    selection-background-color: #2469a8;
    padding: 6px;
}
QLineEdit:focus, QPlainTextEdit:focus, QTextEdit:focus, QComboBox:focus, QSpinBox:focus, QDoubleSpinBox:focus {
    border-color: #4ca3df;
}
QPlainTextEdit#CodeEditor { font-family: JetBrains Mono, Fira Code, monospace; font-size: 10.5pt; }
QPlainTextEdit#Console { font-family: JetBrains Mono, Fira Code, monospace; font-size: 9.5pt; color: #9ee6b2; }
QTabWidget::pane { border: 1px solid #263445; border-radius: 8px; background: #0f161f; top: -1px; }
QTabBar::tab {
    background: #111923;
    border: 1px solid #263445;
    padding: 9px 16px;
    margin-right: 2px;
    border-top-left-radius: 7px;
    border-top-right-radius: 7px;
}
QTabBar::tab:hover { background: #192534; }
QTabBar::tab:selected { background: #1c2a39; border-bottom: 2px solid #4cb7e9; color: #ffffff; }
QTableWidget { gridline-color: #263445; alternate-background-color: #0e151d; }
QHeaderView::section { background: #17222e; color: #cdd8e5; border: 0; border-right: 1px solid #263445; padding: 7px; font-weight: 700; }
QScrollArea { border: 0; }
QScrollBar:vertical { background: #0d141c; width: 11px; margin: 0; }
QScrollBar::handle:vertical { background: #35475a; min-height: 32px; border-radius: 5px; }
QScrollBar::handle:vertical:hover { background: #486079; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QScrollBar:horizontal { background: #0d141c; height: 11px; }
QScrollBar::handle:horizontal { background: #35475a; min-width: 32px; border-radius: 5px; }
QSlider::groove:horizontal { height: 5px; background: #2c3a49; border-radius: 2px; }
QSlider::handle:horizontal { background: #d7e1ec; width: 16px; margin: -6px 0; border-radius: 8px; }
QCheckBox { spacing: 8px; }
QStatusBar { background: #0f161f; border-top: 1px solid #263445; color: #9cabbc; }
QMenuBar { background: #0f161f; border-bottom: 1px solid #202c3a; }
QMenuBar::item { padding: 6px 9px; }
QMenuBar::item:selected, QMenu::item:selected { background: #233244; }
QMenu { background: #121a23; border: 1px solid #304054; padding: 5px; }
QMenu::item { padding: 7px 26px 7px 10px; border-radius: 4px; }
QSplitter::handle { background: #263445; }
QSplitter::handle:hover { background: #3b526a; }
QLabel#Title { font-size: 20pt; font-weight: 850; color: #f6f9fc; }
QLabel#Subtitle, QLabel#Muted { color: #91a2b6; }
QLabel#Hint { color: #91a2b6; padding: 7px 6px; }
QLabel#SectionLabel { font-size: 9pt; font-weight: 850; color: #79d88a; letter-spacing: 1px; }
QLabel#Good { color: #59d875; font-weight: 750; }
QLabel#Warn { color: #e7bc55; font-weight: 750; }
QLabel#Bad { color: #ff747c; font-weight: 750; }
QLabel#MetricValue { font-family: JetBrains Mono, monospace; font-weight: 750; }
QLabel#RunBadge {
    padding: 7px 13px;
    border-radius: 6px;
    font-size: 9pt;
    font-weight: 850;
    min-width: 92px;
}
QLabel#RunBadge[state="running"] { background: #24743a; color: #ffffff; border: 1px solid #35a853; }
QLabel#RunBadge[state="starting"] { background: #5b471c; color: #ffe6a3; border: 1px solid #8a6d2d; }
QLabel#RunBadge[state="error"] { background: #642832; color: #ffd9dc; border: 1px solid #98424e; }
QToolTip { background: #1a2633; color: #f4f7fb; border: 1px solid #455c73; padding: 5px; }
"""
