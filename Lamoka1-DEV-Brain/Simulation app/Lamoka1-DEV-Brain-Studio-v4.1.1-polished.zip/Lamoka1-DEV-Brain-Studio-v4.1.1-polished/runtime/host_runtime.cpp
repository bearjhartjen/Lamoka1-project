#include "devbrain.hpp"

#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <deque>
#include <exception>
#include <string>

namespace {

struct RuntimeState {
    std::array<devbrain::Rgb, devbrain::kLedCount> leds{};
    std::deque<std::string> logs{};
    std::string status{"Waiting for power"};
    std::uint64_t uptime_ms{0};
    std::uint64_t frame_count{0};
    bool power_good{false};
    bool raw_gpio0_level{true};
    bool gpio0_level{true};
    bool previous_gpio0_level{true};
    std::uint32_t raw_stable_ms{0};
    bool button_pressed_edge{false};
    bool button_released_edge{false};
    bool setup_complete{false};
};

RuntimeState g;
constexpr std::size_t kMaxLogs = 256;

void push_log(const char* text) {
    if (!text) return;
    char prefix[48]{};
    std::snprintf(prefix, sizeof(prefix), "[%8.3f s] ", static_cast<double>(g.uptime_ms) / 1000.0);
    if (g.logs.size() >= kMaxLogs) g.logs.pop_front();
    g.logs.emplace_back(std::string(prefix) + text);
}

void clear_outputs() {
    g.leds.fill({0, 0, 0});
}

void start_firmware() {
    g.uptime_ms = 0;
    g.frame_count = 0;
    g.raw_gpio0_level = true;
    g.previous_gpio0_level = true;
    g.raw_stable_ms = 0;
    g.button_pressed_edge = false;
    g.button_released_edge = false;
    g.setup_complete = false;
    clear_outputs();
    g.status = "Starting firmware";
    push_log("Power good. RP2354A firmware startup initiated.");
    push_log("Hardware map: GPIO0 button, GPIO11 WS2812 data, 10 pixels.");
    try {
        setup();
        g.setup_complete = true;
    } catch (const std::exception& e) {
        g.status = "Firmware setup exception";
        push_log(e.what());
    } catch (...) {
        g.status = "Firmware setup exception";
        push_log("Unknown exception from setup().");
    }
}

}  // namespace

namespace devbrain {

namespace leds {
void set(int index, Rgb color) {
    if (index < 0 || index >= kLedCount) return;
    g.leds[static_cast<std::size_t>(index)] = color;
}
void set(int index, std::uint8_t r, std::uint8_t g_, std::uint8_t b) {
    set(index, {r, g_, b});
}
void fill(Rgb color) { g.leds.fill(color); }
void fill(std::uint8_t r, std::uint8_t g_, std::uint8_t b) { fill({r, g_, b}); }
void clear() { clear_outputs(); }
Rgb get(int index) {
    if (index < 0 || index >= kLedCount) return {};
    return g.leds[static_cast<std::size_t>(index)];
}
}  // namespace leds

namespace button {
bool down() { return !g.gpio0_level; }
bool pressed() { return g.button_pressed_edge; }
bool released() { return g.button_released_edge; }
}  // namespace button

std::uint64_t millis() { return g.uptime_ms; }
std::uint64_t frame() { return g.frame_count; }
bool power_good() { return g.power_good; }

void log(const char* text) { push_log(text); }
void set_status(const char* text) { g.status = text ? text : ""; }

}  // namespace devbrain

extern "C" {

int dbfw_api_version() { return 3; }
int dbfw_led_count() { return devbrain::kLedCount; }

void dbfw_reset() {
    g = RuntimeState{};
    push_log("Runtime reset. Waiting for valid 5V, 3V3, and 1V1 rails.");
}

void dbfw_tick(std::uint32_t delta_ms, int gpio0_level, int power_good) {
    delta_ms = std::clamp<std::uint32_t>(delta_ms, 1u, 100u);
    const bool next_power = power_good != 0;
    const bool next_gpio = gpio0_level != 0;

    if (next_power != g.power_good) {
        g.power_good = next_power;
        if (g.power_good) {
            start_firmware();
        } else {
            clear_outputs();
            g.setup_complete = false;
            g.status = "Power removed";
            push_log("Power lost. GPIO and LED outputs forced inactive.");
        }
    }

    if (!g.power_good || !g.setup_complete) {
        g.gpio0_level = next_gpio;
        g.previous_gpio0_level = next_gpio;
        return;
    }

    g.uptime_ms += delta_ms;
    if (next_gpio != g.raw_gpio0_level) {
        g.raw_gpio0_level = next_gpio;
        g.raw_stable_ms = 0;
    } else if (g.raw_stable_ms < 25u) {
        g.raw_stable_ms = std::min<std::uint32_t>(25u, g.raw_stable_ms + delta_ms);
    }
    g.button_pressed_edge = false;
    g.button_released_edge = false;
    if (g.raw_stable_ms >= 25u && g.gpio0_level != g.raw_gpio0_level) {
        g.previous_gpio0_level = g.gpio0_level;
        g.gpio0_level = g.raw_gpio0_level;
        g.button_pressed_edge = g.previous_gpio0_level && !g.gpio0_level;
        g.button_released_edge = !g.previous_gpio0_level && g.gpio0_level;
    }

    try {
        update(delta_ms);
    } catch (const std::exception& e) {
        g.status = "Firmware update exception";
        push_log(e.what());
    } catch (...) {
        g.status = "Firmware update exception";
        push_log("Unknown exception from update().");
    }

    ++g.frame_count;
    g.button_pressed_edge = false;
    g.button_released_edge = false;
}

int dbfw_led_r(int index) {
    return index >= 0 && index < devbrain::kLedCount ? g.leds[static_cast<std::size_t>(index)].r : 0;
}
int dbfw_led_g(int index) {
    return index >= 0 && index < devbrain::kLedCount ? g.leds[static_cast<std::size_t>(index)].g : 0;
}
int dbfw_led_b(int index) {
    return index >= 0 && index < devbrain::kLedCount ? g.leds[static_cast<std::size_t>(index)].b : 0;
}

std::uint64_t dbfw_uptime_ms() { return g.uptime_ms; }
std::uint64_t dbfw_frame_counter() { return g.frame_count; }
int dbfw_gpio0_level() { return g.gpio0_level ? 1 : 0; }
int dbfw_power_good() { return g.power_good ? 1 : 0; }

const char* dbfw_status() { return g.status.c_str(); }

int dbfw_pop_log(char* buffer, int buffer_size) {
    if (!buffer || buffer_size <= 0 || g.logs.empty()) return 0;
    const std::string line = g.logs.front();
    g.logs.pop_front();
    std::snprintf(buffer, static_cast<std::size_t>(buffer_size), "%s", line.c_str());
    return 1;
}

}  // extern "C"
