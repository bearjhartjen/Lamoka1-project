#!/usr/bin/env python3
from __future__ import annotations

import ctypes
import json
import sys
from pathlib import Path


def emit(payload: dict) -> None:
    sys.stdout.write(json.dumps(payload, separators=(",", ":")) + "\n")
    sys.stdout.flush()


class FirmwareLibrary:
    def __init__(self, path: Path) -> None:
        self.lib = ctypes.CDLL(str(path))
        self._configure()
        version = int(self.lib.dbfw_api_version())
        if version != 3:
            raise RuntimeError(f"Unsupported firmware plugin API {version}; expected 3")
        self.lib.dbfw_reset()

    def _configure(self) -> None:
        l = self.lib
        l.dbfw_api_version.restype = ctypes.c_int
        l.dbfw_led_count.restype = ctypes.c_int
        l.dbfw_reset.argtypes = []
        l.dbfw_tick.argtypes = [ctypes.c_uint32, ctypes.c_int, ctypes.c_int]
        for name in ("dbfw_led_r", "dbfw_led_g", "dbfw_led_b"):
            fn = getattr(l, name)
            fn.argtypes = [ctypes.c_int]
            fn.restype = ctypes.c_int
        l.dbfw_uptime_ms.restype = ctypes.c_uint64
        l.dbfw_frame_counter.restype = ctypes.c_uint64
        l.dbfw_gpio0_level.restype = ctypes.c_int
        l.dbfw_power_good.restype = ctypes.c_int
        l.dbfw_status.restype = ctypes.c_char_p
        l.dbfw_pop_log.argtypes = [ctypes.c_char_p, ctypes.c_int]
        l.dbfw_pop_log.restype = ctypes.c_int

    def state(self) -> dict:
        count = int(self.lib.dbfw_led_count())
        leds = [
            [
                int(self.lib.dbfw_led_r(i)),
                int(self.lib.dbfw_led_g(i)),
                int(self.lib.dbfw_led_b(i)),
            ]
            for i in range(count)
        ]
        logs: list[str] = []
        buffer = ctypes.create_string_buffer(1024)
        while self.lib.dbfw_pop_log(buffer, len(buffer)):
            logs.append(buffer.value.decode("utf-8", errors="replace"))
        status_raw = self.lib.dbfw_status()
        return {
            "ok": True,
            "leds": leds,
            "uptime_ms": int(self.lib.dbfw_uptime_ms()),
            "frame": int(self.lib.dbfw_frame_counter()),
            "gpio0": int(self.lib.dbfw_gpio0_level()),
            "power_good": bool(self.lib.dbfw_power_good()),
            "status": status_raw.decode("utf-8", errors="replace") if status_raw else "",
            "logs": logs,
        }

    def command(self, payload: dict) -> dict:
        command = payload.get("cmd")
        if command == "reset":
            self.lib.dbfw_reset()
            return self.state()
        if command == "tick":
            self.lib.dbfw_tick(
                int(payload.get("dt_ms", 16)),
                int(bool(payload.get("gpio0", True))),
                int(bool(payload.get("power_good", False))),
            )
            return self.state()
        if command == "ping":
            result = self.state()
            result["pong"] = True
            return result
        raise ValueError(f"Unknown command: {command!r}")


def main() -> int:
    if len(sys.argv) != 2:
        emit({"ok": False, "error": "usage: runner.py /path/to/libfirmware.so"})
        return 2
    try:
        firmware = FirmwareLibrary(Path(sys.argv[1]).expanduser().resolve())
        emit({"ok": True, "ready": True, **firmware.state()})
        for line in sys.stdin:
            if not line.strip():
                continue
            try:
                payload = json.loads(line)
                if payload.get("cmd") == "shutdown":
                    emit({"ok": True, "shutdown": True})
                    return 0
                emit(firmware.command(payload))
            except Exception as exc:  # noqa: BLE001
                emit({"ok": False, "error": str(exc)})
    except Exception as exc:  # noqa: BLE001
        emit({"ok": False, "fatal": True, "error": str(exc)})
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
