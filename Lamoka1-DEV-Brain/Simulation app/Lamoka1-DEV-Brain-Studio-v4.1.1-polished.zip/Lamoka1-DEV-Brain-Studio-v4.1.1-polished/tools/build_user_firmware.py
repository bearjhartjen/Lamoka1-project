#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description="Compile a DEV-Brain C++ program into a local simulator plugin")
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()

    root = args.root.resolve()
    source = args.source.expanduser().resolve()
    output = args.output.expanduser().resolve()
    compiler = shutil.which(os.environ.get("CXX", "g++"))
    if not compiler:
        print("error: g++ was not found. Install Fedora package gcc-c++.", file=sys.stderr)
        return 127
    if not source.exists():
        print(f"error: firmware source does not exist: {source}", file=sys.stderr)
        return 2

    output.parent.mkdir(parents=True, exist_ok=True)
    command = [
        compiler,
        "-std=c++20",
        "-O2",
        "-g",
        "-Wall",
        "-Wextra",
        "-Wpedantic",
        "-shared",
        "-fPIC",
        "-I",
        str(root / "sdk"),
        str(root / "runtime" / "host_runtime.cpp"),
        str(source),
        "-o",
        str(output),
    ]
    print("$ " + " ".join(command))
    result = subprocess.run(command, text=True)
    if result.returncode == 0:
        print(f"Built simulator firmware: {output}")
    return result.returncode


if __name__ == "__main__":
    raise SystemExit(main())
