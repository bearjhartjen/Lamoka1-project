#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SOURCE="${1:-$ROOT/workspace/firmware.cpp}"
export PICO_SDK_PATH="${PICO_SDK_PATH:-$HOME/pico/pico-sdk}"
if [[ ! -f "$PICO_SDK_PATH/external/pico_sdk_import.cmake" ]]; then
  echo "Pico SDK is not installed. Run: $ROOT/tools/setup_firmware_fedora.sh" >&2
  exit 2
fi
BUILD="$ROOT/workspace/build-rp2354a"
cmake -S "$ROOT/firmware" -B "$BUILD" -G Ninja \
  -DPICO_BOARD=lamoka1_dev_brain \
  -DDEV_BRAIN_USER_SOURCE="$(realpath "$SOURCE")" \
  -DCMAKE_BUILD_TYPE=Release
cmake --build "$BUILD"
echo
printf 'Real board UF2: %s\n' "$BUILD/lamoka1_dev_brain.uf2"
