#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PY="${PYTHON:-python3}"
mkdir -p "$ROOT/workspace/build"
"$PY" -m compileall -q "$ROOT/app" "$ROOT/runtime" "$ROOT/tools" "$ROOT/tests"
"$PY" "$ROOT/tools/build_user_firmware.py" "$ROOT/workspace/firmware.cpp" "$ROOT/workspace/build/libfirmware.so" --root "$ROOT"
PYTHONPATH="$ROOT" "$PY" - <<'PYTEST'
from tests.test_power_model import test_power_sequence, test_partial_usb_has_no_power
test_power_sequence()
test_partial_usb_has_no_power()
print("power model tests passed")
PYTEST
PYTHONPATH="$ROOT" "$PY" "$ROOT/tests/test_runner.py"
for script in "$ROOT"/*.sh "$ROOT"/tools/*.sh; do bash -n "$script"; done
if "$PY" -c 'import PySide6' 2>/dev/null; then
  QT_QPA_PLATFORM=offscreen timeout 8 "$PY" -m app.main --smoke-test
else
  echo 'PySide6 not installed in this environment; GUI smoke test skipped.'
fi
echo 'All available verification checks passed.'
