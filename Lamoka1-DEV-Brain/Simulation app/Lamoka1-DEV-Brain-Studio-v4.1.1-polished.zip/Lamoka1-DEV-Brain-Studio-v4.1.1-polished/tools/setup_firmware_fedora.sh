#!/usr/bin/env bash
set -euo pipefail
sudo dnf install -y git cmake ninja-build arm-none-eabi-gcc-cs arm-none-eabi-gcc-cs-c++ arm-none-eabi-newlib
mkdir -p "$HOME/pico"
if [[ ! -d "$HOME/pico/pico-sdk/.git" ]]; then
  git clone --branch 2.3.0 --depth 1 https://github.com/raspberrypi/pico-sdk.git "$HOME/pico/pico-sdk"
fi
git -C "$HOME/pico/pico-sdk" submodule update --init --recursive
printf '\nPico SDK ready at %s\n' "$HOME/pico/pico-sdk"
