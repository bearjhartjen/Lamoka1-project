#pragma once

#include <cstdint>

namespace devbrain {

inline constexpr int kLedCount = 10;
inline constexpr int kButtonGpio = 0;
inline constexpr int kLedDataGpio = 11;

struct Rgb {
    std::uint8_t r{0};
    std::uint8_t g{0};
    std::uint8_t b{0};
};

namespace leds {
void set(int index, Rgb color);
void set(int index, std::uint8_t r, std::uint8_t g, std::uint8_t b);
void fill(Rgb color);
void fill(std::uint8_t r, std::uint8_t g, std::uint8_t b);
void clear();
Rgb get(int index);
}

namespace button {
bool down();
bool pressed();
bool released();
}

std::uint64_t millis();
std::uint64_t frame();
bool power_good();

void log(const char* text);
void set_status(const char* text);

}  // namespace devbrain

// Every simulated/real firmware program implements these two functions.
void setup();
void update(std::uint32_t delta_ms);
