#!/usr/bin/env bash
# Lamoka1 DEV-Brain Studio — Fedora installer
# Safe upgrade with atomic swap + rollback and full workspace/ preservation.
set -euo pipefail

SOURCE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEST="$HOME/.local/share/lamoka1-devbrain-studio"
BIN_DIR="$HOME/.local/bin"
APP_DIR="$HOME/.local/share/applications"
STAGE="${DEST}.new"
BACKUP="${DEST}.prev"
WORKSPACE_BACKUP=""

trap 'on_error' ERR
on_error() {
  echo "[install] FAILED — attempting rollback…" >&2
  rm -rf "$STAGE" || true
  if [[ -d "$BACKUP" ]]; then
    rm -rf "$DEST" || true
    mv "$BACKUP" "$DEST"
    echo "[install] Restored previous install from $BACKUP" >&2
  fi
  if [[ -n "$WORKSPACE_BACKUP" && -d "$WORKSPACE_BACKUP" && -d "$DEST" ]]; then
    rsync -a --delete "$WORKSPACE_BACKUP/" "$DEST/workspace/" || true
  fi
  exit 1
}

printf 'Installing Lamoka1 DEV-Brain Studio %s\n' "$(cat "$SOURCE/VERSION" 2>/dev/null || echo unknown)"
printf 'Source:      %s\n' "$SOURCE"
printf 'Destination: %s\n\n' "$DEST"

# --- Dependency check -------------------------------------------------------
missing=()
command -v g++ >/dev/null 2>&1                    || missing+=(gcc-c++)
command -v python3 >/dev/null 2>&1                || missing+=(python3)
command -v cmake >/dev/null 2>&1                  || missing+=(cmake)
command -v ninja >/dev/null 2>&1                  || missing+=(ninja-build)
command -v rsync >/dev/null 2>&1                  || missing+=(rsync)
command -v update-desktop-database >/dev/null 2>&1 || missing+=(desktop-file-utils)
if (( ${#missing[@]} )); then
  printf 'Installing missing Fedora packages: %s\n' "${missing[*]}"
  sudo dnf install -y "${missing[@]}"
fi

# --- Preserve the entire user workspace -------------------------------------
if [[ -d "$DEST/workspace" ]]; then
  WORKSPACE_BACKUP="$(mktemp -d --suffix=.devbrain-workspace)"
  rsync -a "$DEST/workspace/" "$WORKSPACE_BACKUP/"
  printf 'Preserved workspace/ (%d files) at %s\n' \
    "$(find "$WORKSPACE_BACKUP" -type f | wc -l)" "$WORKSPACE_BACKUP"
fi

# --- Stage the new install --------------------------------------------------
rm -rf "$STAGE"
mkdir -p "$(dirname "$STAGE")" "$BIN_DIR" "$APP_DIR"
rsync -a --exclude '.git' --exclude '.venv' \
         --exclude 'workspace/build*' --exclude '__pycache__' \
         "$SOURCE/" "$STAGE/"

# Restore user workspace files INTO the staged install (overrides shipped defaults
# for anything the user already has, but keeps any new starter templates we added).
if [[ -n "$WORKSPACE_BACKUP" ]]; then
  rsync -a "$WORKSPACE_BACKUP/" "$STAGE/workspace/"
fi

# --- Detect and copy the exact repository render if present -----------------
IMAGE=""
for candidate in \
  "$HOME/Documents/Lamoka1-project/Images/Lamoka1-DEV-Brain.png" \
  "$HOME/Downloads/Lamoka1-project/Images/Lamoka1-DEV-Brain.png" \
  "$HOME/Lamoka1-project/Images/Lamoka1-DEV-Brain.png"; do
  if [[ -f "$candidate" ]]; then IMAGE="$candidate"; break; fi
done
if [[ -z "$IMAGE" ]]; then
  IMAGE="$(find "$HOME" -maxdepth 6 -type f -path '*/Lamoka1-project/Images/Lamoka1-DEV-Brain.png' -print -quit 2>/dev/null || true)"
fi
if [[ -n "$IMAGE" ]]; then
  cp "$IMAGE" "$STAGE/assets/actual-devbrain.png"
  printf 'Using local repository render:\n  %s\n' "$IMAGE"
elif [[ -f "$STAGE/assets/actual-devbrain.png" ]]; then
  printf 'Using bundled DEV-Brain render (offline).\n'
else
  printf 'No render available; the built-in fallback illustration will be used.\n'
fi

# --- Python venv + PySide ---------------------------------------------------
python3 -m venv "$STAGE/.venv"
"$STAGE/.venv/bin/python" -m pip install --quiet --upgrade pip
if [[ -d "$SOURCE/vendor" ]] && ls "$SOURCE/vendor"/*.whl >/dev/null 2>&1; then
  "$STAGE/.venv/bin/python" -m pip install --no-index --find-links "$SOURCE/vendor" \
      PySide6-Essentials
else
  # Fall back to online install if no vendored wheels shipped with the archive.
  "$STAGE/.venv/bin/python" -m pip install --quiet "PySide6-Essentials>=6.6,<7"
fi

# --- Pre-build the current firmware into a plugin ---------------------------
mkdir -p "$STAGE/workspace/build"
"$STAGE/.venv/bin/python" "$STAGE/tools/build_user_firmware.py" \
  "$STAGE/workspace/firmware.cpp" "$STAGE/workspace/build/libfirmware.so" --root "$STAGE"

# --- Smoke test the app off-screen before promoting -------------------------
QT_QPA_PLATFORM=offscreen "$STAGE/.venv/bin/python" -m compileall -q "$STAGE/app" "$STAGE/runtime" "$STAGE/tools"
(cd "$STAGE" && QT_QPA_PLATFORM=offscreen timeout 12 "$STAGE/.venv/bin/python" -m app.main --smoke-test)

# --- Atomic swap ------------------------------------------------------------
if [[ -d "$DEST" ]]; then
  rm -rf "$BACKUP"
  mv "$DEST" "$BACKUP"
fi
mv "$STAGE" "$DEST"

# --- Launcher + .desktop ----------------------------------------------------
cat > "$BIN_DIR/lamoka-devbrain-studio" <<LAUNCHER
#!/usr/bin/env bash
cd "$DEST"
exec "$DEST/.venv/bin/python" -m app.main "\$@"
LAUNCHER
chmod +x "$BIN_DIR/lamoka-devbrain-studio"
ln -sf "$BIN_DIR/lamoka-devbrain-studio" "$BIN_DIR/lamoka-devbrain-sim"

cat > "$APP_DIR/lamoka-devbrain-studio.desktop" <<DESKTOP
[Desktop Entry]
Type=Application
Version=1.0
Name=Lamoka1 DEV-Brain Studio
Comment=Local DEV-Brain simulator and C++ firmware workbench
Exec=$BIN_DIR/lamoka-devbrain-studio
Icon=$DEST/assets/devbrain-studio.svg
Terminal=false
Categories=Development;Electronics;IDE;
StartupNotify=true
Keywords=RP2354A;WS2812;Firmware;Electronics;Lamoka1;
DESKTOP
chmod 644 "$APP_DIR/lamoka-devbrain-studio.desktop"
ln -sf "$APP_DIR/lamoka-devbrain-studio.desktop" "$APP_DIR/lamoka-devbrain-sim.desktop"
update-desktop-database "$APP_DIR" >/dev/null 2>&1 || true

# Cleanup: keep .prev backup for one upgrade cycle for manual rollback.
[[ -n "$WORKSPACE_BACKUP" && -d "$WORKSPACE_BACKUP" ]] && rm -rf "$WORKSPACE_BACKUP" || true

trap - ERR
printf '\nInstalled successfully.\n  Launch: lamoka-devbrain-studio\n  Previous install kept at: %s (safe to delete)\n\n' "$BACKUP"
