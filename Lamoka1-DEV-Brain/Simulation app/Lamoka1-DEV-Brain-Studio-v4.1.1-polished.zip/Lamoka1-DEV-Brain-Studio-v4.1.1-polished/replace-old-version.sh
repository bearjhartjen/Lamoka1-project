#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
pkill -f 'lamoka1-devbrain-simulator' 2>/dev/null || true
pkill -f 'app.main' 2>/dev/null || true
rm -rf "$HOME/.local/share/lamoka1-devbrain-simulator"
rm -f "$HOME/.local/bin/lamoka-devbrain-sim"
rm -f "$HOME/.local/share/applications/lamoka-devbrain-sim.desktop"
exec "$ROOT/install-fedora.sh"
