# Changelog

## 4.1.1 - UI polish

- Refined dark theme, spacing, contrast, tabs, menus, tables, scrollbars, and focus states.
- Added a unified application header and clearer live board guidance.
- Standardized simulation status badge states.
- Added visible keyboard shortcuts to core firmware actions.
- Improved sidebar sizing and readability.
- Removed generated pytest cache files from the release archive.


## 4.1.0 — Alignment & upgrade safety pass

- **Bundled the exact repository render** (`assets/actual-devbrain.png`) so
  D1–D10 auto-detection works offline right after install — no more waiting
  for the fallback illustration on machines without `Lamoka1-project/`.
- **Re-derived and shipped calibrated coordinates** in
  `assets/board-layout.json`, computed against the actual PCB bounding box
  (`(470,157)–(1449,575)`, aspect `2.342` vs true `70/30`). LED spacing drift
  measured at ≤ 5%; enforced by `tests/test_layout.py`.
- **Installer rewritten to be atomic and safe**:
  - Stages into `${DEST}.new`, promotes with `mv`, keeps `${DEST}.prev` for
    manual rollback.
  - Rolls back automatically on any error via `trap ... ERR`.
  - Preserves the **entire** `workspace/` (not just `firmware.cpp`).
  - Falls back to online PySide6 install if no `vendor/` wheels are shipped.
- **Uninstaller preserves user data by default.** Moves `workspace/` to
  `~/.local/share/lamoka1-devbrain-workspace/` before removing the app. Pass
  `--purge` to delete user data too.
- **Added `update.sh`** as a stable command name for upgrades; delegates to
  `install-fedora.sh`.
- **`.desktop` file** now includes `Version=`, `Keywords=`, and the `IDE`
  category so KDE/GNOME group it with development tools.
- **New tests** (all headless): `test_layout.py`, `test_usb_state.py`,
  `test_upgrade.py`. Existing tests unchanged and still passing.
- **New docs**: `docs/CALIBRATION.md`, `docs/VERIFICATION.md` (an honest
  scope of what was and was not verified in the release environment).

## 4.0.0

Baseline release. See `README.md` for scope.
